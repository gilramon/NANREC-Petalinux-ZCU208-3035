
/***************************** Include Files *********************************/
#include "xil_types.h"

/************************** Constant Definitions *****************************/

/**************************** Type Definitions *******************************/

/***************** Macros (Inline Functions) Definitions *********************/

/************************** Function Prototypes ******************************/

void cli_nco_init(void);
void ncoPhaseAlign(u32 *cmdVals);


/************************** Variable Definitions *****************************/

/************************** Function Definitions ******************************/


