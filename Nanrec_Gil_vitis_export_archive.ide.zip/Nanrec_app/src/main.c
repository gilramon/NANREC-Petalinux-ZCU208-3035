#include <stdio.h>
#include <stdarg.h>
#include "main.h"
#include "xparameters.h"
#include "xil_types.h"
#include "xil_io.h"
#include "sleep.h"
#include "xstatus.h"
#include "xil_printf.h"
#include "xrfdc.h"
#include "LMK_display.h"
#include "LMX_display.h"
#include "xrfclk.h"
#include <metal/log.h>
#include <metal/sys.h>
#include "cli.h"


// Includes for user added CLI functions used in this file
#include "cmd_func_mem.h"
#include "rfdc_poweron_status.h"
#include "rfdc_cmd.h"
#include "adc_FreezeCal.h"
#include "rfdc_nyquistzone.h"
#include "adc_LinkCoupling.h"
#include "rfdc_interpolation_decimation.h"
#include "rfdc_mts.h"
#include "dac_waves.h"
#include "uram_play_cap.h"
#include "rfdc_dsa_vop.h"
#include "adcSaveCalCoefficients.h"
#include "adcGetCalCoefficients.h"
#include "adcLoadCalCoefficients.h"
#include "adcDisableCoeffOvrd.h"
#include "rfdc_nco.h"

#include "xuartps_hw.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <stdbool.h>

#include "xparameters.h"

#include "netif/xadapter.h"

//#include "platform.h"
#include "platform_config.h"
#if defined (__arm__) || defined(__aarch64__)
#include "xil_printf.h"
#endif

#include "lwip/tcp.h"
#include "xil_cache.h"
#include "sleep.h"


#if LWIP_IPV6==1
#include "lwip/ip.h"
#else
#if LWIP_DHCP==1
#include "lwip/dhcp.h"
#endif
#endif

#ifdef XPS_BOARD_ZCU102
#ifdef XPAR_XIICPS_0_DEVICE_ID
int IicPhyReset(void);
#endif
#endif

XRFdc RFdcInst;      /* RFdc driver instance */

#define HISTORY_CLI_SIZE 10

#define STDIN_BASEADDRESS 0xFF000000
#define STDOUT_BASEADDRESS 0xFF000000
#define UART1_BASEADDR      ((u32)0XFF010000U)
#define MAX_SIZE 81
#define MAX_SIZE 81
#define PROJECT_NAME "Eyal-GMI-T"





#define NUMBER_OF_TOKENS 20
char HistoryCLI[HISTORY_CLI_SIZE][MAX_SIZE];
int HistoryPtr = 0;
int HistoryQueuePtr = 0;
char InputString[MAX_SIZE];
int InputStringPtr = 0;
struct netif *netif;
ip_addr_t ipaddr, netmask, gw;


/************************** Function Prototypes ******************************/

void my_metal_default_log_handler(enum metal_log_level level,
			       const char *format, ...);
void printLMKsettings(lmk_config_t *lmkInstPtr);
//static int resetAllClk104(void);
void reverse32bArray(u32 *src, int size);
void printCLK104_settings(void);

/************************** Variable Definitions *****************************/

// VT100 esc sequences
char CHAR_ATTRIB_OFF[5] = "\x1B[0m";
char BOLD_ON[5]      	= "\x1B[1m";
char UNDERLINE_ON[5] 	= "\x1B[4m";
char BLINK_ON[5]        = "\x1B[5m";
char REVERSE_ON[5]    	= "\x1B[5m";

char CLR_SCREEN[5]   	= "\x1B[2J";


// data buffer used for reading PLL registers
static u32 data[256];

const char clkoutBrdNames[][18] = {
		"RFIN_RF1",   "RF1_ADC_SYNC",
		"NC",         "AMS_SYSREF",
		"RFIN_RF2",   "RF2_DAC_SYNC",
		"DAC_REFCLK", "DDR_PL_CAP_SYNC",
		"PL_CLK",     "PL_SYSREF",
		"NC",         "J10 SINGLE END",
		"ADC_REFCLK", "NC",
};

lmk_config_t lmkConfig;
lmx_config_t lmxConfig;

extern XRFdc_MultiConverter_Sync_Config ADC_Sync_Config2;
extern XRFdc_MultiConverter_Sync_Config DAC_Sync_Config2;

extern const u32 LMK_CKin[LMK_FREQ_NUM][LMK_COUNT];
extern const u32 LMX2594[][LMX2594_COUNT];

/* defined by each RAW mode application */
void reverse32bArray(u32 *src, int size);
void str_split(char* i_str, const char i_delim);
void print_app_header();
int start_application();
int transfer_data();
void tcp_fasttmr(void);
void tcp_slowtmr(void);
void ParseInputUart(void);
void Gil_getAndParseInput( void );
void ParseInputString(char * i_str);
void ClearInputString(void);
void ShowPrompt(void);
void ClearTokens(void);
void PrintDebugHistory(void);
void CLI_Print(void);
void removeChar(char *str, char i_char);
void WriteReg32(void);
void ReadReg32(void);
void ReadBlock(void);
void TestBlock(void);
void WriteReg64(void);
void ReadReg64(void);
void MemTest32(void);
void MemTest64(void);
void version(void);
void DeleteHistory(void);
void help(void);
void debug(void);
void reset(void);
void Gil_NCO_SET(void);
void GiladcSetDSA(void);
void Gil_DacSetVOP(void);
void Gil_dacSetNyquistZone(void);
void Gil_adcSetNyquistZone(void);
void Gil_adcDumpStatus(void);
void Gil_dacDumpStatus(void);
void Gil_rfdcPoweronStatus(void);
void Gil_adcSetDSA(void);
void Gil_adcGetDSA(void);
void Gil_rfdcReady(void);
void Gil_dacCurrent(void);
void Gil_adcGetLinkCoupling(void);
void Gil_dacAdcMTSStatus(void);
void Gil_adcFreezeCalStatus(void);
void Gil_rfdcNyquistZone(void);
bool isValidIpv4(void);
void UpdateIPV4(void);
void Print_IP(void);
void UpdateGW(void);
void dummy(void);



// Gil: This is the original functions that I used
//cli_init();
//cli_cmd_func_mem_init();
//cli_rfdc_cmd_init();
//cli_rfdc_poweron_status_init();
//cli_DacAdcIntDec_init();
//cli_rfdcNyquistzone_init();
//cli_adcGetLinkCoupling_init();
//cli_rfdcDSAVOP_init();
//cli_cmd_mts_init();
//cli_adcFreezeCalStatus_init();
//cli_adcGetCalCoefficients_init();
//cli_adcSaveCalCoeff_init();
//cli_adcLoadCalCoeff_init();
//cli_adcDisableCoeffOvrd_init();
//cli_dac_waves_init();
//cli_nco_init();
//cli_uram_play_cap_init();



typedef struct CommandStruct {
	char CommandName[20];
	char Help[150];
	void (*CommandFunc)(void);
} CommandStruct;
CommandStruct * CurrentCommand = 0;



CommandStruct  CLI_Commands[] = {
	{"   ", "---------------------------- IP commands ----------------------------",*dummy}, // Gil Ramon: {Command name, Help)
	{"ipaddr", "Update ip address, example [ipaddr 192.168.1.10]",*UpdateIPV4}, // Gil Ramon: {Command name, Help)
	{"ipgw", "Update gateway address , example [ipgw 192.168.1.10]",*UpdateGW}, // Gil Ramon: {Command name, Help)
	{"prip", "Print ip settings",*Print_IP},
	{"   ", "---------------------------- Write Read registers commands ---------------------------------",*dummy}, // Gil Ramon: {Command name, Help)
    {"wr32", "Write to Register 32 bit address must be aligned to 0x4!! , example: [wr32 a800_0000 77]",*WriteReg32}, // Gil Ramon: {Command name, Help)
    {"rr32", "Read register 32 bit , example:[rr32 a800_0000]",*ReadReg32},
    {"rb", "Read block with length , example [rb a8000000 4]",*ReadBlock},
    {"tb", "write value , the addresses and verify,tb <start address> <stop address>, , example [tb a800_0000 a800_0100]",*TestBlock},
    {"wr64", "Write to Register 64 bit",*WriteReg64},
    {"rr64", "Read register 64 bit",*ReadReg64},
    {"mt32", "Memory test get start address and end address",*MemTest32},
	{"mt64", "Memory test get start address and end address",*MemTest64},
	{"   ", "---------------------------- RFDC commands commands --------------------------------",*dummy}, // Gil Ramon: {Command name, Help)
    {"nco", "NCO set, nco <type:0 adc, 1 dac> <tile: 0-3> <block:0-3> <freqency:double> , example [nco 0 3 0 500.5] ",*Gil_NCO_SET},
	{"adc", "- Dump ADC status" , *Gil_adcDumpStatus},
	{"dac", "- Dump DAC status" , *Gil_dacDumpStatus},
	{"power", "rfdc power status" , *Gil_rfdcPoweronStatus},
	{"dsas", "adcSetDSA, dsas <tile: 0-3> <block:0-3> <Attenuation:float> , example [dsas 3 0 5.1]" , *Gil_adcSetDSA},
	{"dsag", "adcGetDSA" , *Gil_adcGetDSA},
	{"rfred", "rfdcReady" , *Gil_rfdcReady},
	{"cur", "dac Current" , *Gil_dacCurrent},
	{"vop", "Set VOP output, vop <tile: 0-3> <block:0-3> <uACurrent:int>  , example [vop 3 0 20000]" , *Gil_DacSetVOP},
	{"linkc", "adc Get Link Coupling" , *Gil_adcGetLinkCoupling},
	{"mts", "dacAdc MTS Status" , *Gil_dacAdcMTSStatus},
	{"fcal", "adc Freeze Cal Status" , *Gil_adcFreezeCalStatus},
	{"nyq", "rfdc Nyquist Zone get" , *Gil_rfdcNyquistZone},
	{"dacn", "Nyquist_Zone should be between 1-2 , odd=1 even=2 , example [adcn 3 0 2]" , *Gil_dacSetNyquistZone},
	{"adcn", "Nyquist_Zone should be between 1-2 , odd=1 even=2 , example [dacn 3 0 2]" , *Gil_adcSetNyquistZone},
	{"   ", "---------------------------- General commands --------------------------------------",*dummy}, // Gil Ramon: {Command name, Help)
    {"?", "help menu",*help}, ///Gil Ramon - Don't use letter 'h' it's have problems with strtok
    {"ver", "get software version",*version},
	{"reset", "reset the system",*reset},
	{"debug", "set debug level , example [debug 1]",*debug},
	{"prh", "print history commands",*PrintDebugHistory},
	{"ds", "delete history commands",*DeleteHistory},
	//Gil Ramon: for some reason letter 'h' have starnge behavior
	{}
	//{"\0", "end",0}
};

/* missing declaration in lwIP */
void lwip_init();

#if LWIP_IPV6==0
#if LWIP_DHCP==1
extern volatile int dhcp_timoutcntr;
err_t dhcp_start(struct netif *netif);
#endif
#endif


int NumberOfCLICommands = 0;
int DebugFlag = 0;
extern volatile int TcpFastTmrFlag;
extern volatile int TcpSlowTmrFlag;
extern volatile int GilTmrFlag;
static struct netif server_netif;
struct netif *echo_netif;
int NumberOfArguments = 0;
int RandomNumber = 0;
char tokens[NUMBER_OF_TOKENS][30];


void reverse32bArray(u32 *src, int size)
{
	u32 tmp[200];
	int i, j;

	//copy src into temp
	for(i = 0, j=size - 1; i < size; i++, j--) {
		tmp[i] = src[j];
	}

	//copy swapped array to original
	for(i=0; i< size; i++) {
		src[i] = tmp[i];
	}
	return;
}

void Gil_adcSetNyquistZone(void)
{
	XRFdc* RFdcInstPtr = &RFdcInst;
		int Status;
		//u32 Tile_Id;
		//u32 Block_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc_BlockStatus blockStatus;
		u32 GetNyquistZone;
		//u32 Nyquist_Zone;

		if(NumberOfArguments != 3)
		{
			xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
			return;
		}

		u32 Tile_Id = (u32)strtol(tokens[1], NULL, 10);
		u32 Block_Id = (u32)strtol(tokens[2], NULL, 10);
		u32 Nyquist_Zone = (u32)strtol(tokens[3], NULL, 10);

		if(!(Tile_Id <= 3 && Tile_Id >=0))
		{
			xil_printf("\r\n Tile should be between 0-3\r\n ");
			return;
		}

		if(!(Block_Id <= 3 && Block_Id >=0))
		{
			xil_printf("\r\n block should be between 0-3\r\n ");
			return;
		}

		if(!(Nyquist_Zone <= 2 && Nyquist_Zone >=1))
		{
			xil_printf("\r\n Nyquist_Zone should be between 1-2 , odd=1 even=2\r\n ");
			return;
		}

//		Tile_Id = cmdVals[0];
//		Block_Id = cmdVals[1];
//		Nyquist_Zone = cmdVals[2];

		// Calling this function gets the status of the IP
		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
		xil_printf("\n\r###############################################\r\n");
		if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
			xil_printf("Set ADC Nyquist zone...\n\r");
			XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &blockStatus);
			//////////////////////////////////////////////////////////////////////////////
			// ADC Nyquist Zone
			Status = XRFdc_SetNyquistZone(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, Nyquist_Zone);
			if (Status != XST_SUCCESS) {
				xil_printf("XRFdc_SetNyquistZone() for ADC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
				return;
			}

			Status = XRFdc_GetNyquistZone(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &GetNyquistZone);
			if (Status != XST_SUCCESS) {
				xil_printf("XRFdc_GetNyquistZone() for DAC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
				return;
			}

			XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &blockStatus);
			printf("   ADC Tile%d ch%d Nyquist Zone: %d",Tile_Id,Block_Id,GetNyquistZone);
			printf(" - Sampling Frequency: %f GHz.\n\r", blockStatus.SamplingFreq);
		} else{
			xil_printf("ADC Tile%d ch%d is not available.\n\r", Tile_Id, Block_Id);
		}
		xil_printf("###############################################\r\n\n");

		return;
}

void Gil_dacSetNyquistZone(void)
{
	XRFdc* RFdcInstPtr = &RFdcInst;
		int Status;
		//u32 Tile_Id;
	//	u32 Block_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc_BlockStatus blockStatus;
		u32 GetNyquistZone;
	//	u32 Nyquist_Zone;

		if(NumberOfArguments != 3)
		{
			xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
			return;
		}

		u32 Tile_Id = (u32)strtol(tokens[1], NULL, 10);
		u32 Block_Id = (u32)strtol(tokens[2], NULL, 10);
		u32 Nyquist_Zone = (u32)strtol(tokens[3], NULL, 10);

		if(!(Tile_Id <= 3 && Tile_Id >=0))
		{
			xil_printf("\r\n Tile should be between 0-3\r\n ");
			return;
		}

		if(!(Block_Id <= 3 && Block_Id >=0))
		{
			xil_printf("\r\n block should be between 0-3\r\n ");
			return;
		}

		if(!(Nyquist_Zone <= 2 && Nyquist_Zone >=1))
		{
			xil_printf("\r\n Nyquist_Zone should be between 1-2 , odd=1 even=2\r\n ");
			return;
		}




//		Tile_Id = cmdVals[0];
//		Block_Id = cmdVals[1];
//		Nyquist_Zone = cmdVals[2];

		// Calling this function gets the status of the IP
		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
		xil_printf("\n\r###############################################\r\n");
		if(XRFdc_IsDACBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
			xil_printf("Set DAC Nyquist zone...\n\r");
			XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &blockStatus);

			//////////////////////////////////////////////////////////////////////////////
			// DAC Nyquist Zone
			Status = XRFdc_SetNyquistZone(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, Nyquist_Zone);
			if (Status != XST_SUCCESS) {
				xil_printf("XRFdc_SetNyquistZone() for DAC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
				return;
			}

			Status = XRFdc_GetNyquistZone(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetNyquistZone);
			if (Status != XST_SUCCESS) {
				xil_printf("XRFdc_GetNyquistZone() for DAC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
				return;
			}

			XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &blockStatus);
			printf("   DAC Tile%d ch%d Nyquist Zone: %d",Tile_Id,Block_Id,GetNyquistZone);
			printf(" - Sampling Frequency: %f GHz.\n\r", blockStatus.SamplingFreq);
		} else{
			xil_printf("DAC Tile%d ch%d is not available.\n\r", Tile_Id, Block_Id);
		}

		xil_printf("###############################################\r\n\n");

		return;
}

void Gil_rfdcNyquistZone(void)
{
	XRFdc* RFdcInstPtr = &RFdcInst;
	int Status;
	u32 Tile_Id;
	u32 Block_Id;
	XRFdc_IPStatus ipStatus;
	XRFdc_BlockStatus blockStatus;
	u32 GetNyquistZone;



	// Calling this function gets the status of the IP
	XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
	xil_printf("\n\r###############################################\r\n");
	xil_printf("=== DAC Nyquist Zone Report ===\n\r");



	for (Tile_Id=0; Tile_Id<=3; Tile_Id++) {
		if (ipStatus.DACTileStatus[Tile_Id].IsEnabled == 1) {
			for(Block_Id=0; Block_Id<=3; Block_Id++) {
				if(XRFdc_IsDACBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
					XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &blockStatus);

					//////////////////////////////////////////////////////////////////////////////
					// DAC Nyquist Zone
					Status = XRFdc_GetNyquistZone(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetNyquistZone);
					if (Status != XST_SUCCESS) {
						xil_printf("XRFdc_GetNyquistZone() for DAC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
						return;
					}

					XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &blockStatus);
					printf("   DAC Tile%d ch%d Nyquist Zone: %d",Tile_Id,Block_Id,GetNyquistZone);
					printf(" - Sampling Frequency: %f GHz.\n\r", blockStatus.SamplingFreq);
				}
			}
		}
	}


	xil_printf("=== ADC Nyquist Zone Report ===\n\r");


	for (Tile_Id=0; Tile_Id<=3; Tile_Id++) {
		if (ipStatus.ADCTileStatus[Tile_Id].IsEnabled == 1) {

			for(Block_Id=0; Block_Id<=3; Block_Id++) {
				if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
					XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &blockStatus);

					//////////////////////////////////////////////////////////////////////////////
					// DAC Nyquist Zone
					Status = XRFdc_GetNyquistZone(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &GetNyquistZone);
					if (Status != XST_SUCCESS) {
						xil_printf("XRFdc_GetNyquistZone() for ADC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
						return;
					}

					XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &blockStatus);
					printf("   ADC Tile%d ch%d Nyquist Zone: %d",Tile_Id,Block_Id,GetNyquistZone);
					printf(" - Sampling Frequency: %f GHz.\n\r", blockStatus.SamplingFreq);
				}
			}
		}
	}


	xil_printf("###############################################\r\n\n");

	return;
}

void Gil_adcFreezeCalStatus(void)
{
	u32 Tile_Id;
	u32 Block_Id;
	XRFdc_IPStatus ipStatus;
	XRFdc* RFdcInstPtr = &RFdcInst;
	XRFdc_Cal_Freeze_Settings calFreezeSettings;

	Tile_Id = cmdVals[0];
	Block_Id = cmdVals[1];

	XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
	xil_printf("\n\r###############################################\n\r");
	xil_printf("=== ADC Cal Freeze Report ===\n\r");

	for (Tile_Id=0; Tile_Id<=3; Tile_Id++) {
		for(Block_Id=0; Block_Id<=3; Block_Id++) {
			if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
				XRFdc_GetCalFreeze(RFdcInstPtr, Tile_Id, Block_Id, &calFreezeSettings);
				if (calFreezeSettings.CalFrozen == 0){
					xil_printf("   ADC Tile%d ch%d Cal Frozen: %d (Not Frozen)\r\n", Tile_Id, Block_Id,calFreezeSettings.CalFrozen);
				}
				if (calFreezeSettings.CalFrozen  == 1){
					xil_printf("   ADC Tile%d ch%d Cal Frozen: %d (Frozen)\r\n", Tile_Id, Block_Id,calFreezeSettings.CalFrozen);
				}
			}
		}
	}

	xil_printf("###############################################\r\n\n");

	return;
}

void Gil_dacAdcMTSStatus(void)
{
	int i;
	u32 factor;
	XRFdc* RFdcInstPtr = &RFdcInst;
	xil_printf("\r\n###############################################\r\n");
	xil_printf("=== Multi-Tile Sync Report ===\r\n");
	for(i=0; i<4; i++) {
		//if((1<<i)&DAC_Sync_Config2.Tiles)
		{
				XRFdc_GetInterpolationFactor(RFdcInstPtr, i, 0, &factor);
				xil_printf("DAC%d: Latency(T1) =%3d, Adjusted Delay"
				 "Offset(T%d) =%3d\r\n", i, DAC_Sync_Config2.Latency[i],
						 factor, DAC_Sync_Config2.Offset[i]);
		}
	}

	for(i=0; i<4; i++) {
	//	if((1<<i)&ADC_Sync_Config2.Tiles)
		{
			XRFdc_GetDecimationFactor(RFdcInstPtr, i, 0, &factor);
			xil_printf("ADC%d: Latency(T1) =%3d, Adjusted Delay"
			 "Offset(T%d) =%3d\r\n", i, ADC_Sync_Config2.Latency[i],
					 factor, ADC_Sync_Config2.Offset[i]);
		}
	}
	xil_printf("###############################################\r\n\n");
	return;
}

void Gil_adcGetLinkCoupling(void)
{
	u32 Tile_Id;
		u32 Block_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc* RFdcInstPtr = &RFdcInst;
		u32 getlinkCouplingSettings;

		Tile_Id = cmdVals[0];
		Block_Id = cmdVals[1];

		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
		xil_printf("\n\r###############################################\n\r");
		xil_printf("=== ADC Get Link Coupling ===\n\r");

		for (Tile_Id=0; Tile_Id<=3; Tile_Id++) {
			for(Block_Id=0; Block_Id<=3; Block_Id++) {
		//		xil_printf("   ADC Tile%d ch%d \r\n", Tile_Id, Block_Id);
				if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
					XRFdc_GetLinkCoupling(RFdcInstPtr, Tile_Id, Block_Id, &getlinkCouplingSettings);
					if (getlinkCouplingSettings == 1){
						xil_printf("   ADC Tile%d ch%d Link Coupling: %d (AC Coupled)\r\n", Tile_Id, Block_Id,getlinkCouplingSettings);
					}
					if (getlinkCouplingSettings == 0){
						xil_printf("   ADC Tile%d ch%d Link Coupling: %d (DC Coupled)\r\n", Tile_Id, Block_Id,getlinkCouplingSettings);
					}
				}
			}
		}

		xil_printf("###############################################\r\n\n");

		return;
}

void Gil_DacSetVOP(void)
{
//		u32 Tile_Id;
//		u32 Block_Id;
//		u32 uACurrent;
		XRFdc_IPStatus ipStatus;
		XRFdc* RFdcInstPtr = &RFdcInst;
		u32 Status;
		u32 OutputCurr;

		if(NumberOfArguments != 3)
		{
			xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
			return;
		}

		u32 Tile_Id = (u32)strtol(tokens[1], NULL, 10);
		u32 Block_Id = (u32)strtol(tokens[2], NULL, 10);
		u32 uACurrent = (u32)strtol(tokens[3], NULL, 10);



		if(!(Tile_Id <= 3 && Tile_Id >=0))
		{
			xil_printf("\r\n Tile should be between 0-3\r\n ");
			return;
		}

		if(!(Block_Id <= 3 && Block_Id >=0))
		{
			xil_printf("\r\n block should be between 0-3\r\n ");
			return;
		}
		//	u32 Value = (u32)strtol(tokens[2], NULL, 16);

		printf("\n\rTile_Id = [%d] Block_Id = [%d] uACurrent = [%d]\r\n",Tile_Id,Block_Id,uACurrent);



		// Calling this function gets the status of the IP
		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
		xil_printf("\n\r###############################################\r\n");

		if (RFdcInstPtr->RFdc_Config.IPType >= XRFDC_GEN3) {

			if(XRFdc_IsDACBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {

				// DAC Set Output Power
				Status = XRFdc_SetDACVOP(RFdcInstPtr,  Tile_Id, Block_Id, uACurrent);
				if (Status != XST_SUCCESS) {
					xil_printf("XRFdc_SetDACVOP() for DAC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
					return;
				}
				else{
					Status = XRFdc_GetOutputCurr(RFdcInstPtr, Tile_Id, Block_Id, &OutputCurr);
					xil_printf("   DAC Tile%d ch%d VOP set to %d uA.\n\r",Tile_Id,Block_Id,OutputCurr);
				}
			}
			else{
				xil_printf("DAC Tile%d ch%d is not available.\n\r", Tile_Id, Block_Id);
			}
			}
		else{
			xil_printf("This command is for RFSoC Gen3 devices only.\n\r");
		}

			xil_printf("###############################################\r\n");
			return;
}




void ParseInputUart(void)
{
	u32 RecievedByte;
	u8 IsFoundinTheHistory = 0;
			/* Wait until there is data */
//	0XFF010000U
			RecievedByte = XUartPs_ReadReg(STDIN_BASEADDRESS, XUARTPS_FIFO_OFFSET);
			if(RecievedByte == 0)
			{
				return;
			}
			if(InputStringPtr >=MAX_SIZE)
			{
				xil_printf( "\r\n Max length reached [%s]",InputString);

				ClearInputString();
				ClearTokens();
				//while(1);
				return;
			}
		//	xil_printf( "\r\n [0x%x]",RecievedByte);
			switch(RecievedByte) {
					case 0:
							   break;
					case 0x0D: // Enter pressed

								//InputStringPtr++;
							if(strcmp(InputString,"") != 0)
							{

								//search for the next history
								for(int i =0 ; i < HISTORY_CLI_SIZE ; i++)
								{
									if(strcmp(HistoryCLI[i],InputString) == 0)
									{
										IsFoundinTheHistory = 1;
									}

								}

								InputString[InputStringPtr] = 0;

								if(IsFoundinTheHistory == 0)
								{

									strcpy(HistoryCLI[HistoryQueuePtr],InputString);

									HistoryPtr = HistoryQueuePtr;

									HistoryQueuePtr++;

									if(HistoryQueuePtr >= HISTORY_CLI_SIZE )
									{
										HistoryQueuePtr = 0;
									}
								}



								removeChar(InputString,'_');
								ParseInputString(InputString);



							}

							ShowPrompt();
							ClearInputString();
							ClearTokens();


							   break;
					case 0x0A:
							   break;
					case 0x08: xil_printf("\b \b");
								if(InputStringPtr > 0)
								{
									InputStringPtr--;
								}
							   break;

					case 0x44: xil_printf("\b \b"); //back arrow
								if(InputStringPtr > 0)
								{
									InputStringPtr--;
								}
							   break;

//					case 0x42:     //down arrow
//						if(strcmp(HistoryCLI[HistoryPtr],"") != 0)
//						{
//
//
//
//							ClearInputString();
//							strcpy(InputString,HistoryCLI[HistoryPtr]);
//							if(HistoryPtr < HISTORY_CLI_SIZE)
//							{
//								HistoryPtr++;
//							}
//							InputStringPtr = strlen(InputString);
//							ShowPrompt();
//							//xil_printf(" %c", InputString[0]); // Gil Ramon: There was a bug that I didn't understand that the first character won't printed.
//							xil_printf("%s", InputString);
//
//						}
//						else
//						{
//							HistoryPtr = 0;
////							if(HistoryPtr < HISTORY_CLI_SIZE)
////							{
////								HistoryPtr++;
////							}
//						}
//
//							   break;

					case 0x41:     //up arrow

//						for(int i = 0; i < strlen(InputString) ;i++)
//						{
//							xil_printf("\b \b");
//						}


						if(strcmp(HistoryCLI[HistoryPtr],"") != 0)
						{
							ClearInputString();
							strcpy(InputString,HistoryCLI[HistoryPtr]);


							HistoryPtr--;
							if(HistoryPtr < 0)
							{
								for(int i =0 ; i < HISTORY_CLI_SIZE ; i++)
								{
									if(strcmp(HistoryCLI[i],"") != 0)
									{
										HistoryPtr = i;
									}

								}
							}




							InputStringPtr = strlen(InputString);
							ShowPrompt();
							//xil_printf(" %s> ",PROJECT_NAME);
							//xil_printf(" %c", InputString[0]); // Gil Ramon: There was a bug that I didn't understand that the first character won't printed.


							xil_printf("%s", InputString);
						}
						else
						{
							HistoryPtr--;
							if(HistoryPtr < 0)
							{
								HistoryPtr = HISTORY_CLI_SIZE - 1;
							}
						}

							   break;

					default:
						//	if ( isalpha ( RecievedByte ) || isdigit(RecievedByte) || isspace(RecievedByte) )
							{
								xil_printf("%c",RecievedByte);		//echo key entered
								InputString[InputStringPtr] = RecievedByte;
								InputStringPtr++;
							}

							break;
			}



			return ;
}



void ClearInputString(void)
{
	memset(InputString,0,MAX_SIZE);
	InputStringPtr = 0;
	return;
}

void ShowPrompt(void)
{
	xil_printf( "\r\n%s> ",PROJECT_NAME);
	//xil_printf( "\n\r> ");
	return;
}

void PrintDebugHistory(void)
{


		xil_printf("\r\n");
		for(int i=0 ; i < HISTORY_CLI_SIZE ; i++)
		{
			xil_printf("\r\n %d:[%s]",i,HistoryCLI[i]);
			usleep(10000);
		}
		xil_printf("\r\n HistoryPtr [%d]",HistoryPtr);
		xil_printf("\r\n HistoryQueuePtr [%d]",HistoryQueuePtr);

}

void ClearTokens(void)
{
	for(int i=0; i < NUMBER_OF_TOKENS;i++)
	{
		tokens[i][0] = '\0';
	}
}




void ExecteTheCommand(void)
{
	int i=0;
	for(i=0; i < NumberOfCLICommands ;i++)
	{
		CommandStruct * temp = &CLI_Commands[i];
		if( strcmp(temp->CommandName,tokens[0]) == 0)
		{
			CurrentCommand = temp;

			if(strcmp("0000",tokens[1]) == 0)
			{
				xil_printf("\r\n Command [%s] \r\n\r\n help: %s",CurrentCommand->CommandName,CurrentCommand->Help);
			}
			else
			{
				(*temp->CommandFunc)();
			}
			return;
		}

	}
	xil_printf("\r\nCommand Not found");
}

void ParseInputString(char * i_str)
{

	//usleep(10000);

			//usleep(10000);
//	printf(" Input [%s]\n",i_str);
		str_split(i_str,' ');

	    if(DebugFlag == 1)
	    {
			printf("\n");
			int i = 0;
			while(*tokens[i] != 0)
			{
				printf("[%d] = [%s]\n",i, tokens[i]);
				i++;
			}
			printf("\n Number Of Arguments [%d]\r\n",NumberOfArguments);
	    }



	    ExecteTheCommand();

}

void str_split(char* i_str, const char i_delim)
{
	  char *ch;
	  int i=0;
	  ch = strtok(i_str, &i_delim);
	  while (ch != NULL) {
	 //   printf("\r\n%s", ch);
		 strcpy(tokens[i],ch);
		 i++;
	    ch = strtok(NULL, &i_delim);
	  }
	//  getch();
	  NumberOfArguments = i -1;
    return ;
}

void removeChar(char *str, char i_char)
{

    char *src, *dst;
    for (src = dst = str; *src != '\0'; src++) {
        *dst = *src;
        if (*dst != i_char) dst++;
    }
    *dst = '\0';
}

void WriteReg32(void)
{
	if(NumberOfArguments != 2)
	{
		xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}


	u32 Addr = (u32)strtol(tokens[1], NULL, 16);
	u32 Value = (u32)strtol(tokens[2], NULL, 16);

	if(Addr % 4 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x4, Addr = [0x%x] Value = [0x%x]\r\n ",Addr,Value);
		return;
	}

	UINTPTR WrittenAddress = Addr;

	xil_printf("\r\n Written Address [0x%x] Written Value [0x%x]\r\n ",WrittenAddress,Value);

	Xil_Out32((UINTPTR)Addr,Value);
}

void ReadReg32(void)
{
	if(NumberOfArguments != 1)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}


	UINTPTR Addr = (UINTPTR)strtol(tokens[1], NULL, 16);
	//u32 Value = (UINTPTR)strtol(tokens[2], NULL, 0);

	if(Addr % 4 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x4\r\n ");
		return;
	}

	u32 Value = Xil_In32(Addr);
	xil_printf("\r\n Address [0x%x] Data: [0x%x] \r\n ",Addr,Value);
}

void WriteReg64(void)
{
	if(NumberOfArguments != 2)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}
	UINTPTR Addr = (UINTPTR)strtol(tokens[1], NULL, 0);
	u64 Value = (UINTPTR)strtol(tokens[2], NULL, 0);

	if(Addr % 8 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x8\r\n ");
		return;
	}

	Xil_Out64(Addr,Value);
}

void ReadReg64(void)
{
	if(NumberOfArguments != 1)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}
	u64 Addr = strtol(tokens[1], NULL, 0);

	if(Addr % 8 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x8\r\n ");
		return;
	}

	//u32 Value = (UINTPTR)strtol(tokens[2], NULL, 0);
	u64 Value = Xil_In64(Addr);
	xil_printf("\r\n Address [0x%lx] Data: [0x%lx] \r\n ",Addr,Value);
}

void help(void)
{
	CLI_Print();
}


void reset(void)
{
	exit(0);
}


void version(void)
{
	xil_printf("\r\n version date [%s,%s] \r\n ",__DATE__,__TIME__);
}

void debug(void)
{
	if(NumberOfArguments != 1)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}

	DebugFlag = atoi(tokens[1]);
}

void ReadBlock(void)
{
	if(NumberOfArguments != 2)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}


	UINTPTR Addr = (UINTPTR)strtol(tokens[1], NULL, 16);
	u32 Length = (UINTPTR)strtol(tokens[2], NULL, 0);

	if(Addr % 4 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x4\r\n ");
		return;
	}

	for(int i=0; i < Length; i++)
	{
		u32 Value = Xil_In32(Addr);
		xil_printf("\r\n Address [0x%lx] Data: [0x%lx] ",Addr,Value);
		Addr += 4;
	}


}

void TestBlock(void)
{
	if(NumberOfArguments != 2)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}


	UINTPTR Start_Addr = (UINTPTR)strtol(tokens[1], NULL, 16);
	u32 Stop_Addr = (UINTPTR)strtol(tokens[2], NULL, 16);

	if(Start_Addr % 4 != 0 || Stop_Addr % 4 !=0)
	{
		xil_printf("\r\n Address must be aligned to 0x4\r\n ");
		return;
	}


	if(Stop_Addr < Start_Addr)
	{
		xil_printf("\r\n Stop address must be bigger than start address\r\n ");
		return;
	}
	u8 TestSucceed = 1;
	int i = 0;
	xil_printf("\r\n");
	while(Start_Addr != Stop_Addr)
	{
		i++;
		Xil_Out32(Start_Addr,i);
		u32 Value = Xil_In32(Start_Addr);

		if(i % 100000 == 0)
		{
		xil_printf(" . ");
		}

		if(Value != i)
		{
			xil_printf("\r\n Address [0x%lx] Data: [0x%lx] Failed",Start_Addr,Value);
			TestSucceed = 0;
		}
		Start_Addr += 4;
	}

//	for(int i=0; i < Length; i++)
//	{
//		Xil_Out32(Addr,i);
//		u32 Value = Xil_In32(Addr);
//
//		if(i % 100000 == 0)
//		{
//			xil_printf(" . ");
//		}
//
//		if(Value != i)
//		{
//			xil_printf("\r\n Address [0x%lx] Data: [0x%lx] Failed",Addr,Value);
//			TestSucceed = 0;
//		}
//		Addr += 4;
//	}

	if(TestSucceed == 1)
	{
		xil_printf("\r\n Test Passed OK \r\n ");
	}
	else
	{
		xil_printf("\r\n Test Failed \r\n ");
	}


}

void DeleteHistory(void)
{
	if(NumberOfArguments != 0)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}

	for(int i =0 ; i < HISTORY_CLI_SIZE ; i++)
	{
		HistoryCLI[i][0] = '\0';

	}
	HistoryPtr = 0;
	HistoryQueuePtr = 0;

}

void Gil_rfdcPoweronStatus(void)
{
	u32 Tile_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc* RFdcInstPtr = &RFdcInst;
		u32 val;
	    XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);

		xil_printf("\r\n###############################################\r\n");
		xil_printf("The Power-on sequence step. 0xF is complete.\r\n");

		for ( Tile_Id=0; Tile_Id<=3; Tile_Id++) {
			if (ipStatus.DACTileStatus[Tile_Id].IsEnabled == 1) {
	    		val = XRFdc_ReadReg16(RFdcInstPtr, XRFDC_DAC_TILE_CTRL_STATS_ADDR(Tile_Id), XRFDC_ADC_DEBUG_RST_OFFSET);
	    		if(val & XRFDC_DBG_RST_CAL_MASK) {
	    			xil_printf("  Tile: %d NOT ready.\r\n", Tile_Id);
	    		} else {
	    		    xil_printf("   DAC Tile%d Power-on Sequence Step: 0x%08x\r\n",Tile_Id,
	    		    	Xil_In32(RFDC_BASE + 0x0000C + 0x04000 + Tile_Id * 0x4000));
	    		}
	    	}
		}

		for ( Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	    	if (ipStatus.ADCTileStatus[Tile_Id].IsEnabled == 1) {
	    		val = XRFdc_ReadReg16(RFdcInstPtr, XRFDC_ADC_TILE_CTRL_STATS_ADDR(Tile_Id), XRFDC_ADC_DEBUG_RST_OFFSET);
	    		if(val & XRFDC_DBG_RST_CAL_MASK) {
	    			xil_printf("  ADC Tile%d NOT ready.\r\n", Tile_Id);
	    		} else {
	    		    xil_printf("   ADC Tile%d Power-on Sequence Step: 0x%08x\r\n",Tile_Id,
	    		    		Xil_In32(RFDC_BASE + 0x0000C + 0x14000 + Tile_Id * 0x4000));
	    		}
	    	}
		}


		xil_printf("###############################################\r\n\n");


		return;
}

void Gil_dacDumpStatus(void)
{
	XRFdc* RFdcInstPtr = &RFdcInst;
		int Status;
		u32 Tile_Id;
		u32 Block_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc_BlockStatus blockStatus;
		XRFdc_Mixer_Settings GetMixer_Settings;
		u32 InterpolationFactor;
		XRFdc_QMC_Settings GetQMCSettings;
		XRFdc_CoarseDelay_Settings GetCoarseDelaySettings;
		u32 GetDecoderMode;
		u32 GetNyquistZone;
		u32 GetFabricRate;

	    // Calling this function gets the status of the IP
	    XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);

	    for (Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	        xil_printf("=================================================\r\n");
	    	if (ipStatus.DACTileStatus[Tile_Id].IsEnabled == 1) {
				xil_printf("Tile: %d DAC Enabled\r\n", Tile_Id);
				xil_printf("  BlockStatus:  0x%x\r\n", ipStatus.DACTileStatus[Tile_Id].BlockStatusMask);
				xil_printf("  TileState:    0x%08x\r\n", ipStatus.DACTileStatus[Tile_Id].TileState);
				xil_printf("  PowerUpState: 0x%08x\r\n", ipStatus.DACTileStatus[Tile_Id].PowerUpState);
				xil_printf("  PLLState:     0x%08x\r\n", ipStatus.DACTileStatus[Tile_Id].PLLState);

				for(Block_Id=0; Block_Id<=3; Block_Id++) {
					if(XRFdc_IsDACBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
						xil_printf("  ***********************************\r\n");
						xil_printf("  Block: %d Enabled\r\n", Block_Id);

						//////////////////////////////////////////////////////////////////////////////
						// blockStatus
						XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &blockStatus);
						printf("    SamplingFreq:          %f\r\n", blockStatus.SamplingFreq);
						xil_printf("    DigitalDataPathStatus: %d\r\n", blockStatus.DigitalDataPathStatus);
						xil_printf("    AnalogDataPathStatus:  %d\r\n", blockStatus.AnalogDataPathStatus);
						xil_printf("    IsFIFOFlagsEnabled:    %d\r\n", blockStatus.IsFIFOFlagsEnabled);
						xil_printf("    IsFIFOFlagsAsserted:   %d\r\n", blockStatus.IsFIFOFlagsAsserted);
						xil_printf("    DataPathClocksStatus:  %d\r\n", blockStatus.DataPathClocksStatus);


						//////////////////////////////////////////////////////////////////////////////
						// DAC Interpolation factor
						Status = XRFdc_GetInterpolationFactor(RFdcInstPtr, Tile_Id, Block_Id, &InterpolationFactor);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetInterpolationFactor() failed\r\n");
							return;
						}
						xil_printf("    Interpolation Factor:  %d\r\n",InterpolationFactor);

						//////////////////////////////////////////////////////////////////////////////
						// DAC Fabric Rate
						Status = XRFdc_GetFabWrVldWords(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetFabricRate);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetFabWrVldWords() failed\r\n");
							return;
						}
						xil_printf("    Fabric Rate         :  %d\r\n",GetFabricRate);

						//////////////////////////////////////////////////////////////////////////////
						// DAC Decoder Mode
						Status = XRFdc_GetDecoderMode(RFdcInstPtr, Tile_Id, Block_Id, &GetDecoderMode);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetDecoderMode() failed\n\r");
							return;
						}
						xil_printf("    Decoder Mode        :  %d\r\n",GetDecoderMode);


						//////////////////////////////////////////////////////////////////////////////
						// DAC Nyquist Zone
						Status = XRFdc_GetNyquistZone(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetNyquistZone);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetNyquistZone() failed\n\r");
							return;
						}
						xil_printf("    Nyquist Zone        :  %d\r\n",GetNyquistZone);


						//////////////////////////////////////////////////////////////////////////////
						// MixerSettings
				        Status =  XRFdc_GetMixerSettings(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetMixer_Settings);
						if (Status != XST_SUCCESS) {
					      xil_printf("Getting Fine Mixer failed\r\n");
						  	return ;
						}

						xil_printf("    **********Mixer Settings*********\r\n");
				        printf("    FREQ:              %f\r\n", GetMixer_Settings.Freq);
				        printf("    PHASE OFFSET:      %f\r\n", GetMixer_Settings.PhaseOffset);
				        xil_printf("    EVENT SOURCE:      %d\r\n", GetMixer_Settings.EventSource);
				        xil_printf("    MIXER MODE:        %d: ", GetMixer_Settings.MixerMode);
				        switch(GetMixer_Settings.MixerMode) {
				        case XRFDC_MIXER_MODE_OFF: xil_printf("OFF");
				        	break;
				        case XRFDC_MIXER_MODE_C2C: xil_printf("C2C");
				        	break;
				        case XRFDC_MIXER_MODE_C2R: xil_printf("C2R");
				        	break;
				        case XRFDC_MIXER_MODE_R2C: xil_printf("R2C");
				        	break;
				        default: xil_printf("unknown");
				        }
				        xil_printf("\r\n");

				        xil_printf("    COARSE MIXER FREQ: %d\r\n", GetMixer_Settings.CoarseMixFreq);


						//////////////////////////////////////////////////////////////////////////////
						// QMC Settings
				        Status = XRFdc_GetQMCSettings(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetQMCSettings);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetQMCSettings() failed\n\r");
							return;
						}

						xil_printf("    **********QMC Settings***********\r\n");
				        printf("    GainCorrectionFactor:   %f\r\n", GetQMCSettings.GainCorrectionFactor);
				        printf("    PhaseCorrectionFactor:  %f\r\n", GetQMCSettings.PhaseCorrectionFactor);
				        xil_printf("    EnablePhase:            %d\r\n", GetQMCSettings.EnablePhase);
				        xil_printf("    EnableGain:             %d\r\n", GetQMCSettings.EnableGain);
				        xil_printf("    OffsetCorrectionFactor: %d\r\n", GetQMCSettings.OffsetCorrectionFactor);
				        xil_printf("    EventSource:            %d\r\n", GetQMCSettings.EventSource);


						//////////////////////////////////////////////////////////////////////////////
						// Coarse Delay Settings
						Status = XRFdc_GetCoarseDelaySettings(RFdcInstPtr, XRFDC_DAC_TILE, Tile_Id, Block_Id, &GetCoarseDelaySettings);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetCoarseDelaySettings() failed\n\r");
							return;
						}
						xil_printf("    ******Coarse Delay Settings******\r\n");
				        xil_printf("    CoarseDelay:            %d\r\n", GetCoarseDelaySettings.CoarseDelay);
				        xil_printf("    EventSource:            %d\r\n", GetCoarseDelaySettings.EventSource);


					} else {
						xil_printf("  ***********************************\r\n");
						xil_printf("  Block: %d Disabled\r\n", Block_Id);
					}
				}
	    	} else {
				xil_printf("Tile: %d DAC Disabled\r\n", Tile_Id);
	    	}
	    }


	    return;
}

void Gil_adcDumpStatus(void)
{
	XRFdc* RFdcInstPtr = &RFdcInst;
		int Status;
		u32 Tile_Id;
		u32 Block_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc_BlockStatus blockStatus;
		XRFdc_Mixer_Settings GetMixer_Settings;
		XRFdc_QMC_Settings GetQMCSettings;
		XRFdc_CoarseDelay_Settings GetCoarseDelaySettings;
		u32 GetNyquistZone;
		u32 DecimationFactor;

	    // Calling this function gets the status of the IP
		Status =  XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);

	    for (Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	        xil_printf("=================================================\r\n");
	    	if (ipStatus.ADCTileStatus[Tile_Id].IsEnabled == 1) {
				xil_printf("Tile: %d ADC Enabled\r\n", Tile_Id);
				xil_printf("  BlockStatus:  0x%x\r\n", ipStatus.ADCTileStatus[Tile_Id].BlockStatusMask);
				xil_printf("  TileState:    0x%08x\r\n", ipStatus.ADCTileStatus[Tile_Id].TileState);
				xil_printf("  PowerUpState: 0x%08x\r\n", ipStatus.ADCTileStatus[Tile_Id].PowerUpState);
				xil_printf("  PLLState:     0x%08x\r\n", ipStatus.ADCTileStatus[Tile_Id].PLLState);

				for(Block_Id=0; Block_Id<=3; Block_Id++) {
					if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
						xil_printf("  ***********************************\r\n");
						xil_printf("  Block: %d Enabled\r\n", Block_Id);

						//////////////////////////////////////////////////////////////////////////////
						// blockStatus
						XRFdc_GetBlockStatus(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &blockStatus);
						printf("    SamplingFreq:          %f\r\n", blockStatus.SamplingFreq);
						xil_printf("    DigitalDataPathStatus: %d\r\n", blockStatus.DigitalDataPathStatus);
						xil_printf("    AnalogDataPathStatus:  %d\r\n", blockStatus.AnalogDataPathStatus);
						xil_printf("    IsFIFOFlagsEnabled:    %d\r\n", blockStatus.IsFIFOFlagsEnabled);
						xil_printf("    IsFIFOFlagsAsserted:   %d\r\n", blockStatus.IsFIFOFlagsAsserted);
						xil_printf("    DataPathClocksStatus:  %d\r\n", blockStatus.DataPathClocksStatus);


						//////////////////////////////////////////////////////////////////////////////
						// Nyquist Zone
						Status = XRFdc_GetNyquistZone(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &GetNyquistZone);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetNyquistZone() failed\n\r");
							return;
						}
						xil_printf("    Nyquist Zone        :  %d\r\n", GetNyquistZone);


						//////////////////////////////////////////////////////////////////////////////
						// MixerSettings
				        Status =  XRFdc_GetMixerSettings(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &GetMixer_Settings);
						if (Status != XST_SUCCESS) {
					      xil_printf("Getting Fine Mixer failed Status = [%d]\r\n",Status);
						//  	return ;
						}

						xil_printf("    **********Mixer Settings*********\r\n");
				        printf("    FREQ:              %f\r\n", GetMixer_Settings.Freq);
				        printf("    PHASE OFFSET:      %f\r\n", GetMixer_Settings.PhaseOffset);
				        xil_printf("    EVENT SOURCE:      %d\r\n", GetMixer_Settings.EventSource);
				        xil_printf("    MIXER MODE:        %d: ", GetMixer_Settings.MixerMode);
				        switch(GetMixer_Settings.MixerMode) {
				        case XRFDC_MIXER_MODE_OFF: xil_printf("OFF");
				        	break;
				        case XRFDC_MIXER_MODE_C2C: xil_printf("C2C");
				        	break;
				        case XRFDC_MIXER_MODE_C2R: xil_printf("C2R");
				        	break;
				        case XRFDC_MIXER_MODE_R2C: xil_printf("R2C");
				        	break;
				        default: xil_printf("unknown");
				        }
				        xil_printf("\r\n");
				        xil_printf("    COARSE MIXER FREQ: %d\r\n", GetMixer_Settings.CoarseMixFreq);


						//////////////////////////////////////////////////////////////////////////////
						// QMC Settings
				        Status = XRFdc_GetQMCSettings(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &GetQMCSettings);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetQMCSettings() failed\n\r");
							return;
						}

						xil_printf("    **********QMC Settings***********\r\n");
				        printf("    GainCorrectionFactor:   %f\r\n", GetQMCSettings.GainCorrectionFactor);
				        printf("    PhaseCorrectionFactor:  %f\r\n", GetQMCSettings.PhaseCorrectionFactor);
				        xil_printf("    EnablePhase:            %d\r\n", GetQMCSettings.EnablePhase);
				        xil_printf("    EnableGain:             %d\r\n", GetQMCSettings.EnableGain);
				        xil_printf("    OffsetCorrectionFactor: %d\r\n", GetQMCSettings.OffsetCorrectionFactor);
				        xil_printf("    EventSource:            %d\r\n", GetQMCSettings.EventSource);


						//////////////////////////////////////////////////////////////////////////////
						// Coarse Delay Settings
						Status = XRFdc_GetCoarseDelaySettings(RFdcInstPtr, XRFDC_ADC_TILE, Tile_Id, Block_Id, &GetCoarseDelaySettings);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetCoarseDelaySettings() failed\n\r");
							return;
						}
						xil_printf("    ******Coarse Delay Settings******\r\n");
				        xil_printf("    CoarseDelay:            %d\r\n", GetCoarseDelaySettings.CoarseDelay);
				        xil_printf("    EventSource:            %d\r\n", GetCoarseDelaySettings.EventSource);

	   					//////////////////////////////////////////////////////////////////////////////
	   					// Decimation Factor
						Status = XRFdc_GetDecimationFactor(RFdcInstPtr, Tile_Id, Block_Id, &DecimationFactor);
						if (Status != XST_SUCCESS) {
							xil_printf("XRFdc_GetDecimationFactor() failed\r\n");
							return;
						}

						xil_printf("    ******Decimation Factor**********\r\n");
						xil_printf("    Decimation Factor:      %d\r\n", DecimationFactor);

					} else {
						xil_printf("  ***********************************\r\n");
						xil_printf("  Block: %d Disabled\r\n", Block_Id);
					}
				}
	    	} else {
				xil_printf("Tile: %d DAC Disabled\r\n", Tile_Id);
	    	}
	    }

	    return;
}

void Gil_NCO_SET(void)
{
	xil_printf("\r\n Gil Run NCO set\r\n ");
	//u32 * Dummy;

	if(NumberOfArguments != 4)
	{
		xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}

	u32 type = (u32)strtol(tokens[1], NULL, 10);
	u32 tile = (u32)strtol(tokens[2], NULL, 10);
	u32 block = (u32)strtol(tokens[3], NULL, 10);
	//u32 Freq = (u32)strtol(tokens[4], NULL, 10);
	double Freq = strtod (tokens[4],NULL);
	if(!(type <= 1 && type >=0))
	{
		xil_printf("\r\n type should be between 0-1\r\n ");
		return;
	}


	if(!(tile <= 3 && tile >=0))
	{
		xil_printf("\r\n Tile should be between 0-3\r\n ");
		return;
	}

	if(!(block <= 3 && block >=0))
	{
		xil_printf("\r\n block should be between 0-3\r\n ");
		return;
	}
//	u32 Value = (u32)strtol(tokens[2], NULL, 16);

	xil_printf("\r\n New frequency [0x%x]\r\n ",Freq);

	//rfdcSetMixerEvntSrc(Dummy);
	rfSetMixerFreqOptPrint(type, tile, block, Freq,1);
}


void MemTest64(void)
{
	if(NumberOfArguments != 2)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}
	int IsTestPass = 1;
	UINTPTR Addr_Start = (UINTPTR)strtol(tokens[1], NULL, 0);

	UINTPTR Addr_End = (UINTPTR)strtol(tokens[2], NULL, 0);
//	u32 Length = (UINTPTR)strtol(tokens[2], NULL, 0);

	if(Addr_Start % 8 != 0 || Addr_End % 8 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x8\r\n ");
		return;
	}

	srand(RandomNumber);   // Initialization, should only be called once.
	//int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
	UINTPTR Addr;
	int cnt = 0;
	for(Addr=Addr_Start; Addr <= Addr_End; Addr+=8)
	{
		if(cnt % 10000 == 0)
		{
			xil_printf(".");
		}
		cnt++;
		u32 Written_Value= rand();
		Xil_Out64(Addr,Written_Value);
		u32 Result = Xil_In64(Addr);
		if(Result != Written_Value)
		{
			IsTestPass = 0;
			xil_printf("\r\n Fail :-( Address [0x%lx] Written_Value: [0x%lx] Result: [0x%lx]",Addr,Written_Value,Result);

		}
		else
		{
			//xil_printf("\r\n OK :-) Address [0x%lx] Written_Value: [0x%lx] Result: [0x%lx]",Addr,Written_Value,Result);
		}
	}

	if(IsTestPass == 1)
	{
		xil_printf("\r\n Test Pass :-)");
	}



}


void MemTest32(void)
{
	if(NumberOfArguments != 2)
	{
		xil_printf("\r\n Not argument command [%s] format [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}
	int IsTestPass = 1;
	UINTPTR Addr_Start = (UINTPTR)strtol(tokens[1], NULL, 0);

	UINTPTR Addr_End = (UINTPTR)strtol(tokens[2], NULL, 0);
//	u32 Length = (UINTPTR)strtol(tokens[2], NULL, 0);

	if(Addr_Start % 4 != 0 || Addr_End % 4 != 0)
	{
		xil_printf("\r\n Address must be aligned to 0x4\r\n ");
		return;
	}

	srand(RandomNumber);   // Initialization, should only be called once.
	//int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
	UINTPTR Addr;
	int cnt = 0;
	for(Addr=Addr_Start; Addr <= Addr_End; Addr+=4)
	{
		if(cnt % 10 == 0)
		{
			xil_printf(".");
		}
		cnt++;
		u32 Written_Value= rand();
		Xil_Out32(Addr,Written_Value);
		u32 Result = Xil_In32(Addr);
		if(Result != Written_Value)
		{
			IsTestPass = 0;
			xil_printf("\r\n Fail :-( Address [0x%lx] Written_Value: [0x%lx] Result: [0x%lx]",Addr,Written_Value,Result);

		}
		else
		{
			//xil_printf("\r\n OK :-) Address [0x%lx] Written_Value: [0x%lx] Result: [0x%lx]",Addr,Written_Value,Result);
		}
	}

	if(IsTestPass == 1)
	{
		xil_printf("\r\n Test Pass :-)");
	}

}



#if LWIP_IPV6==1
void print_ip6(char *msg, ip_addr_t *ip)
{
	print(msg);
	xil_printf(" %x:%x:%x:%x:%x:%x:%x:%x\n\r",
			IP6_ADDR_BLOCK1(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK2(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK3(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK4(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK5(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK6(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK7(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK8(&ip->u_addr.ip6));

}
#else
void
print_ip(char *msg, ip_addr_t *ip)
{
	print(msg);
	xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip),
			ip4_addr3(ip), ip4_addr4(ip));
}

void
print_ip_settings(ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw)
{

	print_ip("Board IP: ", ip);
	print_ip("Netmask : ", mask);
	print_ip("Gateway : ", gw);
}
#endif

#if defined (__arm__) && !defined (ARMR5)
#if XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT == 1 || XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT == 1
int ProgramSi5324(void);
int ProgramSfpPhy(void);
#endif
#endif

#ifdef XPS_BOARD_ZCU102
#ifdef XPAR_XIICPS_0_DEVICE_ID
int IicPhyReset(void);
#endif
#endif


void CLI_Print(void)
{
	xil_printf( "\r\n----------------------------------------------\r\n");
	xil_printf( "---------------CLI [%s]-----------------\r\n",PROJECT_NAME);
	xil_printf( "----------------------------------------------\r\n");

	int i=0;
	CommandStruct * temp = &CLI_Commands[0];

	while(strcmp(temp->CommandName,"") != 0 )
	{
		xil_printf( "%s : %s\r\n",temp->CommandName,temp->Help);
		i++;
		temp = &CLI_Commands[i];
	}
	NumberOfCLICommands = i;
	xil_printf( "\r\nNumber of commands [%d]\r\n",NumberOfCLICommands);
	//xil_printf( "\r\nIn Order to see help write the command with 0000 for example writereg32 0000\r\n");

	version();
}

void BlinkLed()
{
	static char Led_Counter=0;
	//Led_Counter++;
	u32 Addr = 0xa01a000c;
	//Xil_Out32(Addr,Led_Counter);
	Xil_Out32((UINTPTR)Addr,Led_Counter);

	if(Led_Counter == 0)
	{
		Led_Counter = 0xf;
	}
	else
	{
		Led_Counter = 0;
	}
}


int main_thread();
void print_echo_app_header();
void echo_application_thread(void *);

void lwip_init();

#if LWIP_IPV6==0
#if LWIP_DHCP==1
extern volatile int dhcp_timoutcntr;
err_t dhcp_start(struct netif *netif);
#endif
#endif

#define THREAD_STACKSIZE 1024

static struct netif server_netif;
struct netif *echo_netif;

#if LWIP_IPV6==1
void print_ip6(char *msg, ip_addr_t *ip)
{
	print(msg);
	xil_printf(" %x:%x:%x:%x:%x:%x:%x:%x\n\r",
			IP6_ADDR_BLOCK1(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK2(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK3(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK4(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK5(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK6(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK7(&ip->u_addr.ip6),
			IP6_ADDR_BLOCK8(&ip->u_addr.ip6));
}

#else



#endif
int main()
{
	sys_thread_new("main_thrd", (void(*)(void*))main_thread, 0,
	                THREAD_STACKSIZE,
	                DEFAULT_THREAD_PRIO);
	vTaskStartScheduler();
	while(1);
	return 0;
}

void network_thread(void *p)
{

    /* the mac address of the board. this should be unique per board */
    unsigned char mac_ethernet_address[] = { 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };
#if LWIP_IPV6==0

#if LWIP_DHCP==1
    int mscnt = 0;
#endif
#endif

    netif = &server_netif;

    xil_printf("\r\n\r\n");
    xil_printf("-----lwIP Socket Mode ------\r\n");

#if LWIP_IPV6==0
#if LWIP_DHCP==0
    /* initialize IP addresses to be used */
    IP4_ADDR(&ipaddr,  10, 0, 1, 10);
    IP4_ADDR(&netmask, 255, 255, 255,  0);
    IP4_ADDR(&gw,      10, 0, 1, 1);
#endif

    /* print out IP settings of the board */

#if LWIP_DHCP==0
    print_ip_settings(&ipaddr, &netmask, &gw);
    /* print all application headers */
#endif

#if LWIP_DHCP==1
	ipaddr.addr = 0;
	gw.addr = 0;
	netmask.addr = 0;
#endif
#endif

#if LWIP_IPV6==0
    /* Add network interface to the netif_list, and set it as default */
    if (!xemac_add(netif, &ipaddr, &netmask, &gw, mac_ethernet_address, PLATFORM_EMAC_BASEADDR)) {
	xil_printf("Error adding N/W interface\r\n");
	return;
    }
#else
    /* Add network interface to the netif_list, and set it as default */
    if (!xemac_add(netif, NULL, NULL, NULL, mac_ethernet_address, PLATFORM_EMAC_BASEADDR)) {
	xil_printf("Error adding N/W interface\r\n");
	return;
    }

    netif->ip6_autoconfig_enabled = 1;

    netif_create_ip6_linklocal_address(netif, 1);
    netif_ip6_addr_set_state(netif, 0, IP6_ADDR_VALID);

    print_ip6("\n\rBoard IPv6 address ", &netif->ip6_addr[0].u_addr.ip6);
#endif

    netif_set_default(netif);

    /* specify that the network if is up */
    netif_set_up(netif);

    /* start packet receive thread - required for lwIP operation */
    sys_thread_new("xemacif_input_thread", (void(*)(void*))xemacif_input_thread, netif,
            20000,
			3);

#if LWIP_IPV6==0
#if LWIP_DHCP==1
    dhcp_start(netif);
    while (1) {
		vTaskDelay(DHCP_FINE_TIMER_MSECS / portTICK_RATE_MS);
		dhcp_fine_tmr();
		mscnt += DHCP_FINE_TIMER_MSECS;
		if (mscnt >= DHCP_COARSE_TIMER_SECS*1000) {
			dhcp_coarse_tmr();
			mscnt = 0;
		}
	}
#else
    xil_printf("\r\n");
    //xil_printf("Eyal GMI Port: [%6d]\r\n", echo_port);
//    xil_printf("%20s %6s %s\r\n", "Server", "Port", "Connect With..");
//    xil_printf("%20s %6s %s\r\n", "--------------------", "------", "--------------------");

    print_echo_app_header();
    xil_printf("\r\n");
    sys_thread_new("echod", echo_application_thread, 0,
		1024,
		3);
    vTaskDelete(NULL);
#endif
#else
    print_echo_app_header();
    xil_printf("\r\n");
    sys_thread_new("echod",echo_application_thread, 0,
		THREAD_STACKSIZE,
		DEFAULT_THREAD_PRIO);
    vTaskDelete(NULL);
#endif
    return;
}


//static int resetAllClk104(void)
//{
//	int ret = EXIT_FAILURE;
////	printf("Reset LMK\n\r");
//	if (XST_FAILURE == XRFClk_ResetChip(RFCLK_LMK)) {
//		printf("Failure in XRFClk_ResetChip(RFCLK_LMK)\n\r");
//		return ret;
//	}
//
////	printf("Reset LMX2594_1\n\r");
//	if (XST_FAILURE == XRFClk_ResetChip(RFCLK_LMX2594_1)) {
//		printf("Failure in XRFClk_ResetChip(RFCLK_LMX2594_1)\n\r");
//		return ret;
//	}
//
////	printf("Reset LMX2594_2\n\r");
//	if (XST_FAILURE == XRFClk_ResetChip(RFCLK_LMX2594_2)) {
//		printf("Failure in XRFClk_ResetChip(RFCLK_LMX2594_2)\n\r");
//		return ret;
//	}
//
//#ifdef XPS_BOARD_ZCU111
////	printf("Reset LMX2594_3\n\r");
//	if (XST_FAILURE == XRFClk_ResetChip(RFCLK_LMX2594_3)) {
//		printf("Failure in XRFClk_ResetChip(RFCLK_LMX2594_3)\n\r");
//		return ret;
//	}
//#endif
//
//	return EXIT_SUCCESS;
//}



/****************************************************************************/
/**
*
* Print LMK PLL device settings such as input and output clk frequencies.
* The instance structure is initialized by calling LMK_init()
*
* @param
*	- lmkInstPtr a pointer to the LMK instance structure
*
* @return
*	- void
*
* @note		None
*
****************************************************************************/
void printLMKsettings(lmk_config_t *lmkInstPtr)
{


#ifdef LMK_DEBUG
    LMK_intermediateDump(lmkInstPtr);
#endif

    // Print LMK CLKin frequencies
    if(lmkInstPtr->clkin_sel_mode == LMK_CLKin_SEL_MODE_AUTO_MODE ) {
    	xil_printf("CLKin Auto Mode Enabled\n\r");
    }
    for(int i=0; i<3; i++) {
    	if(lmkInstPtr->clkin[i].freq != -1) {
    		xil_printf("CLKin%d_freq: %12ldKHz\n\r", i, lmkInstPtr->clkin[i].freq/1000);
    	}
    }

    // Print LMK CLKout frequencies
	for(int i=0; i<7; i++) {
		xil_printf("DCLKout%02d(%-10s):", i*2, clkoutBrdNames[i*2]);
		if(lmkInstPtr->clkout[i].dclk_freq == -1) {
			xil_printf("%12s", "-----");
		} else {
			xil_printf("%9ldKHz", lmkInstPtr->clkout[i].dclk_freq/1000);
		}

		xil_printf(" SDCLKout%02d(%-15s):", i*2 + 1, clkoutBrdNames[i*2 +1]);
		if(lmkInstPtr->clkout[i].sclk_freq == -1) {
			xil_printf("%12s\n\r", "-----");
		} else {
			xil_printf("%9ldKHz\n\r", lmkInstPtr->clkout[i].sclk_freq/1000);
		}
	}
}

/****************************************************************************/
/**
*
* Print LMX PLL device output clk frequencies.
* The instance structure is initialized by calling LMX_SettingsInit()
*
* @param
* 	- clkin is the clk freq fed into the LMX PLL. This value is used to
* 	  calculate and display the output frequencies
*	- lmxInstPtr a pointer to the LMX instance structure
*
* @return
*	- void
*
* @note		None
*
****************************************************************************/
void printLMXsettings(long int clkin, lmx_config_t *lmxInstPtr)
{


#ifdef LMX_DEBUG
    LMX_intermediateDump(lmxInstPtr);
#endif

    // Print LMX CLKin freq
    xil_printf("CLKin_freq: %10ldKHz\n\r", clkin/1000);


    // Print LMX CLKout frequencies
	xil_printf("RFoutA Freq:");
	if(lmxInstPtr->RFoutA_freq == -1) {
		xil_printf("%13s\n\r", "-----");
	} else {
		xil_printf("%10ldKHz\n\r", lmxInstPtr->RFoutA_freq/1000);
	}

	xil_printf("RFoutB Freq:");
	if(lmxInstPtr->RFoutB_freq == -1) {
		xil_printf("%13s\n\r", "-----");
	} else {
		xil_printf("%10ldKHz\n\r", lmxInstPtr->RFoutB_freq/1000);
	}

}

/****************************************************************************/
/**
*
* Reads the configuration of LMK and LMX PLL then calculates and displays
* the PLL frequencies and settings.
* The instance structures ar initialized by calling LMK_init() or
* LMX_SettingsInit()
*
* @param
* 	- nil
*
* @return
*	- void
*
* @note		None
*
****************************************************************************/
//void printCLK104_settings(void)
//{
//	char pllNames[3][9] = {"LMK ----", "LMX_RF1", "LMX_RF2"};
//	u32  chipIds[3] = {RFCLK_LMK, RFCLK_LMX2594_1, RFCLK_LMX2594_2};
//
//	for(int i=0; i<3; i++) {
//		if (XST_FAILURE == XRFClk_GetConfigFromOneChip(chipIds[i], data)) {
//			printf("Failure in XRFClk_GetConfigFromOneChip()\n\r");
//			return;
//		}
//
//		// For LMX, reverse readback data to match exported register sets and
//		// order of LMX2594[][]
//		if(chipIds[i] != RFCLK_LMK) {
//			reverse32bArray(data, LMX2594_COUNT-3);
//		}
//
//#if 0
//		// Dump raw data read from device
//		printf("Config data is:\n\r");
//		for (int j = 0; j < ((chipIds[i]==RFCLK_LMK) ? LMK_COUNT : LMX2594_COUNT-3); j++) {
//			printf("%08X, ", data[j]);
//			if( !(j % 6) ) printf("\n\r");
//		}
//		printf("\n\r");
//#endif
//
//		// Display clock values of device
//		printf("Clk settings read from %s ---------------------\n\r", pllNames[i]);
//		if(chipIds[i] == RFCLK_LMK) {
//			LMK_init(data, &lmkConfig);
//			printLMKsettings(&lmkConfig);
//		} else {
//			// clkout index is i=1 idx = 0, i=2 idx=2. i&2 meets this alg
//			LMX_SettingsInit(lmkConfig.clkout[ (i & 2) ].dclk_freq, data, &lmxConfig);
//			printLMXsettings(lmkConfig.clkout[ (i & 2) ].dclk_freq, &lmxConfig);		}
//		xil_printf("\n\r");
//	}
//}

void Gil_dacCurrent(void)
{
	int Status;
		XRFdc* RFdcInstPtr = &RFdcInst;
		XRFdc_IPStatus ipStatus;
		u32 Tile_Id;
		u32 Block_Id;
		u32 OutputCurr;
		u32 OutputCurr2;

	//	u32 OutputCurrSet;
		// Calling this function gets the status of the IP
		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);

		xil_printf("\r\n###############################################\r\n");
		xil_printf("=== Data Current Report ===\n\r");

		for ( Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	    	if (ipStatus.DACTileStatus[Tile_Id].IsEnabled == 1) {
				for ( Block_Id=0; Block_Id<=3; Block_Id++) {
					if (XRFdc_IsDACBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id) != 0U) {
						Status = XRFdc_GetOutputCurr(RFdcInstPtr, Tile_Id, Block_Id, &OutputCurr);
						if (RFdcInstPtr->RFdc_Config.IPType < XRFDC_GEN3) {
							if (Status != XST_SUCCESS) {
								xil_printf("XRFdc_GetOutputCurr() failed for DAC Tile%d Ch%d.\r\n",Tile_Id,Block_Id);
								return;
							}
							switch(OutputCurr) {
								case XRFDC_OUTPUT_CURRENT_20MA:
									xil_printf("   DAC Tile%d Ch%d output current is 20mA. DAC_AVTT should be 2.5V\r\n",Tile_Id,Block_Id);
									break;
								case XRFDC_OUTPUT_CURRENT_32MA:
									xil_printf("   DAC Tile%d Ch%d output current is 32mA. DAC_AVTT should be 3.0V\r\n",Tile_Id,Block_Id);
									break;
								default:
									xil_printf("DAC output current is not recognized.  Channel may not be enabled.\r\n");
									break;
							}
							}// gen3
							else{
								Status = XRFdc_GetDACCompMode(RFdcInstPtr, Tile_Id, Block_Id, &OutputCurr2);
								if (Status != XST_SUCCESS) {
									xil_printf("XRFdc_GetDACCompMode() failed for DAC Tile%d Ch%d.\r\n",Tile_Id,Block_Id);
									return;
									}
									switch(OutputCurr2) {
										case 0:
											xil_printf("   DAC Tile%d Ch%d output current mode is set to RFSoC Gen3.\r\n",Tile_Id,Block_Id);
											xil_printf("   DAC Tile%d Ch%d output current is set to %d uA.\r\n",Tile_Id,Block_Id,OutputCurr);
											break;
										case 1:
											xil_printf("   DAC Tile%d Ch%d output current mode is set to RFSoC Gen1/2.\r\n",Tile_Id,Block_Id);
											break;
										default:
											xil_printf("DAC output current is not recognized.  Channel may not be enabled.\r\n");
											break;
									}

							}
	    			}
	    		}
			}
		}
		xil_printf("###############################################\r\n\n");

		return;
}

void Gil_rfdcReady(void)
{
	u32 Tile_Id;
		XRFdc_IPStatus ipStatus;
		XRFdc* RFdcInstPtr = &RFdcInst;
		u32 val;

		// Calling this function gets the status of the IP
		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);

		xil_printf("\r\n###############################################\r\n");
		xil_printf("=== Data Converter Status Report ===\n\r");


		xil_printf("DAC Status\r\n");
		for ( Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	    	if (ipStatus.DACTileStatus[Tile_Id].IsEnabled == 1) {
	    		val = XRFdc_ReadReg16(RFdcInstPtr, XRFDC_DAC_TILE_CTRL_STATS_ADDR(Tile_Id), XRFDC_ADC_DEBUG_RST_OFFSET);
	    		if(val & XRFDC_DBG_RST_CAL_MASK) {
	    			xil_printf("   Tile: %d NOT ready\r\n", Tile_Id);
	    		} else {
	    			xil_printf("   Tile: %d ready\r\n", Tile_Id);
	    		}
	    	}
		}

		xil_printf("ADC Status\r\n");
		for ( Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	    	if (ipStatus.ADCTileStatus[Tile_Id].IsEnabled == 1) {
	    		val = XRFdc_ReadReg16(RFdcInstPtr, XRFDC_ADC_TILE_CTRL_STATS_ADDR(Tile_Id), XRFDC_ADC_DEBUG_RST_OFFSET);
	    		if(val & XRFDC_DBG_RST_CAL_MASK) {
	    			xil_printf("   Tile: %d NOT ready\r\n", Tile_Id);
	    		} else {
	    			xil_printf("   Tile: %d ready\r\n", Tile_Id);
	    		}
	    	}
		}
		xil_printf("###############################################\r\n\n");

		return;
}

void Gil_adcGetDSA(void)
{
	u32 Tile_Id;
		u32 Block_Id;
		u32 Status;
		float Attenuation2;
		XRFdc_IPStatus ipStatus;
		XRFdc* RFdcInstPtr = &RFdcInst;

		XRFdc_DSA_Settings DSA_Settings;

		// Calling this function gets the status of the IP
		XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);

		xil_printf("\r\n###############################################\r\n");
		xil_printf("=== ADC DSA Report ===\n\r");

		for ( Tile_Id=0; Tile_Id<=3; Tile_Id++) {
	    	if (ipStatus.ADCTileStatus[Tile_Id].IsEnabled == 1) {
				for ( Block_Id=0; Block_Id<=3; Block_Id++) {
					if (XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id) != 0U) {
						if (RFdcInstPtr->RFdc_Config.IPType >= XRFDC_GEN3) {

							if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {

								// ADC Set Attenuation
								Status = XRFdc_GetDSA(RFdcInstPtr,  Tile_Id, Block_Id, &DSA_Settings);
								Attenuation2 = DSA_Settings.Attenuation;
								if (Status != XST_SUCCESS) {
									xil_printf("XRFdc_SetDSA() for ADC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
									return;
								}
								else{
									printf("   ADC Tile%d ch%d DSA set to %.1f dB.\n\r",Tile_Id,Block_Id,Attenuation2);
								}
							}
							else{
								xil_printf("ADC Tile%d ch%d is not available.\n\r", Tile_Id, Block_Id);
							}
							}
						else{
							xil_printf("This command is for RFSoC Gen3 devices only.\n\r");
						}
	    			}
	    		}
			}
		}
		xil_printf("###############################################\r\n");

		return;
}

void Gil_adcSetDSA(void)
{
//	u32 Tile_Id;
//	u32 Block_Id;
	u32 Status;

	float Attenuation_get;
	XRFdc_IPStatus ipStatus;
	XRFdc* RFdcInstPtr = &RFdcInst;
	XRFdc_DSA_Settings DSA_Settings;

	//u32 * Dummy;

	if(NumberOfArguments != 3)
	{
		xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName,NumberOfArguments);
		return;
	}

	u32 Tile_Id = (u32)strtol(tokens[1], NULL, 10);
	u32 Block_Id = (u32)strtol(tokens[2], NULL, 10);
	float Attenuation = strtod (tokens[3],NULL);
	//u32 Freq = (u32)strtol(tokens[4], NULL, 10);

	if(!(Tile_Id <= 3 && Tile_Id >=0))
	{
		xil_printf("\r\n Tile should be between 0-3\r\n ");
		return;
	}

	if(!(Block_Id <= 3 && Block_Id >=0))
	{
		xil_printf("\r\n block should be between 0-3\r\n ");
		return;
	}

	printf("\n\rTile_Id = [%d] Block_Id = [%d] Attenuation = [%f]\r\n",Tile_Id,Block_Id,Attenuation);

//	xil_printf("\r\nSet Attenuation in dB to : ");
//	Attenuation = mygetlinef();

	// Calling this function gets the status of the IP
	XRFdc_GetIPStatus(RFdcInstPtr, &ipStatus);
	xil_printf("\n\r###############################################\r\n");

	if (RFdcInstPtr->RFdc_Config.IPType >= XRFDC_GEN3) {

		if(XRFdc_IsADCBlockEnabled(RFdcInstPtr, Tile_Id, Block_Id)) {
			DSA_Settings.Attenuation = Attenuation;
			// ADC Set Attenuation
			Status = XRFdc_SetDSA(RFdcInstPtr,  Tile_Id, Block_Id, &DSA_Settings);
			if (Status != XST_SUCCESS) {
				xil_printf("XRFdc_SetDSA() for ADC Tile%d ch%d failed.\n\r",Tile_Id,Block_Id);
				return;
			}
			else{
				Status = XRFdc_GetDSA(RFdcInstPtr,  Tile_Id, Block_Id, &DSA_Settings);
				Attenuation_get = DSA_Settings.Attenuation;

				printf("   ADC Tile%d ch%d DSA set to %.1f dB.\n\r",Tile_Id,Block_Id,Attenuation_get);
			}
		}
		else{
			xil_printf("ADC Tile%d ch%d is not available.\n\r", Tile_Id, Block_Id);
		}
		}  // Gen1 or Gen2
	else{
		xil_printf("This command is for RFSoC Gen3 devices only.\n\r");
	}
		xil_printf("###############################################\r\n");
		return;
}


int Gil_RFDC_init(void)
{
	u32  Val;
	u32  Minor;
	u32  Major;
	int Status;
	XRFdc_Config *ConfigPtr;
	//cmdExitVal=0;
//	int lmkConfigIndex;
	//xil_printf("\n\r###############################################\n\r");
		//xil_printf("Hello RFSoC World!\n\r\n");

		// Display IP version
		Val = Xil_In32(RFDC_BASE + 0x00000);
		Major = (Val >> 24) & 0xFF;
		Minor = (Val >> 16) & 0xFF;

		xil_printf("RFDC IP Version: %d.%d\r\n",Major,Minor);


		////////////////////////////////////////////////////////
		// Configure zcu111 clks
	//	xil_printf("\nConfiguring the data converter clocks...\r\n");

		// initialize and reset CLK104 devices on i2c and i2c muxes
//		XRFClk_Init();
//
//		if (resetAllClk104() == EXIT_FAILURE) {
//			xil_printf("resetAllClk104() failed\n\r");
//			return XST_FAILURE;
//		}

		//xil_printf("Configuring CLK104 LMK and LMX devices\r\n");

		/* Set config on all chips */
		// using below LMK config index
		//lmkConfigIndex = 3;

//		if (XST_FAILURE == XRFClk_SetConfigOnAllChipsFromConfigId(lmkConfigIndex, LMX2594_FREQ_300M00_PD, LMX2594_FREQ_300M00_PD)) {
//		printf("Failure in XRFClk_SetConfigOnAllChipsFromConfigId()\n\r");
//			return XST_FAILURE;
//		}

		//printCLK104_settings();

		///////////////////////////////////////////////////
		/* Close spi connections to clk104 */
		//XRFClk_Close();

	    sleep(2);

	//	xil_printf("\nThe design is ready to use.\r\n");
		//xil_printf("Open XSCT or the terminal to run commands.\r\n");
	//	xil_printf("###############################################\n\r");


	//	xil_printf("\r\n--------------- Entering main() ---------------\n\r");


		/////////////////////////////////////////////////////////////////////////////////
		// Initialize RFdc
		//	.log_level		= METAL_LOG_DEBUG,
		//  .log_level		= METAL_LOG_INFO,



	#ifdef ENABLE_METAL_PRINTS
	    xil_printf("=== Metal log enabled ===\n\r");

		struct metal_init_params init_param = {	\
				.log_handler	= my_metal_default_log_handler,	\
				.log_level		= METAL_LOG_DEBUG,			\

		};
	#else
		struct metal_init_params init_param = METAL_INIT_DEFAULTS;
	#endif

		if (metal_init(&init_param)) {
			xil_printf("ERROR: Failed to run metal initialization     !!!!!\n");
			return XRFDC_FAILURE;
		}

		/* Initialize the RFdc driver. */
		ConfigPtr = XRFdc_LookupConfig(RFDC_DEVICE_ID);
		if (ConfigPtr == NULL) {
			xil_printf("Failed to init RFdc driver     !!!!!\r\n");
			return XST_FAILURE;
		}else{
			xil_printf("\n\rDeviceID: %d \r\nSilicon Revision: %d\r\n", ConfigPtr->DeviceId, ConfigPtr->SiRevision);
		}

		ConfigPtr->ADCTile_Config[0].SamplingRate = 0x0;
		/* Initializes the controller */
		Status = XRFdc_CfgInitialize(&RFdcInst, ConfigPtr);
		if (Status != XST_SUCCESS) {
			xil_printf("Failed to init RFdc controller    !!!!!\r\n");
			return XST_FAILURE;
		}
//
//		ConfigPtr->ADCTile_Config[0].SamplingRate = 0x0;
//		printf("Gil: ConfigPtr->ADCTile_Config[0].SamplingRate = [0x%x] \r\n",ConfigPtr->ADCTile_Config[0].SamplingRate);
//		printf("Gil: ConfigPtr->ADCTile_Config[0].SamplingRate = [0x%x] \r\n",ConfigPtr->ADCTile_Config[1].SamplingRate);
//		printf("Gil: ConfigPtr->ADCTile_Config[0].SamplingRate = [0x%x] \r\n",ConfigPtr->ADCTile_Config[2].SamplingRate);
//		printf("Gil: ConfigPtr->ADCTile_Config[0].SamplingRate = [0x%x] \r\n",ConfigPtr->ADCTile_Config[3].SamplingRate);
//
//		printf("Gil: ConfigPtr->ADCTile_Config[0].RefClkFreq = [0x%x] \r\n",ConfigPtr->ADCTile_Config[0].RefClkFreq);
//		printf("Gil: ConfigPtr->ADCTile_Config[0].RefClkFreq = [0x%x] \r\n",ConfigPtr->ADCTile_Config[1].RefClkFreq);
//		printf("Gil: ConfigPtr->ADCTile_Config[0].RefClkFreq = [0x%x] \r\n",ConfigPtr->ADCTile_Config[2].RefClkFreq);
//		printf("Gil: ConfigPtr->ADCTile_Config[0].RefClkFreq = [0x%x] \r\n",ConfigPtr->ADCTile_Config[3].RefClkFreq);


		/////////////////////////////////////////////////////////////////////////////////
		// Display various configurations/status of RFDC




		// Restart the data converters - related to clock configuration
		rfdcStartup(NULL);

		//display ready status for ADCs and DACs
		rfdcReady(NULL);

		// Display current setting for DAC 0 in tile 0
		dacCurrent(NULL);

		/////////////////////////////////////////////////////////////////////////////////
		// Misc initialization specific to this design

		// Initialize buffer address and size for DAC Player
//		{
//			u32 vals[] = { (u64)URAM_PLAY_BASE >> 32, (URAM_PLAY_BASE & 0xFFFFFFFF), 128 };
//			waveSetBuf(vals);
//		}

		{
			int clr_val = 0;
			   xil_printf("=== Initialize ADC coefficients array ===\n\r");

				for (clr_val=0; clr_val < NUM_SETS; clr_val++)
				{
					u32 tmp[] = { (u32)clr_val };
					adcCoeffClr(tmp);
				}
			   xil_printf("\n\r");

		}

		return  XST_SUCCESS;
}

void SendWriteToUart1(void)
{

    u32 RecievedByte = 0;

	RecievedByte = XUartPs_ReadReg(UART1_BASEADDR, XUARTPS_FIFO_OFFSET);
	if(RecievedByte == 0)
	{
		return;
	}
	XUartPs_WriteReg(UART1_BASEADDR, XUARTPS_FIFO_OFFSET, (u32)RecievedByte);

}

int main_thread()
{
#if LWIP_DHCP==1
	int mscnt = 0;
#endif

#ifdef XPS_BOARD_ZCU102
	IicPhyReset();
#endif

	/* initialize lwIP before calling sys_thread_new */
    lwip_init();

    /* any thread using lwIP should be created using sys_thread_new */
    sys_thread_new("NW_THRD", network_thread, NULL,
    		THREAD_STACKSIZE,
            DEFAULT_THREAD_PRIO);

    Gil_RFDC_init();




   // vTaskDelay(150);
	int i=0;
	ClearInputString();
	CLI_Print();
	ShowPrompt();
    while(1)
    {
		if(i % 100000 == 0)
		{
			ParseInputUart();

		//	SendWriteToUart1();

		}

		// Led
//		if(i % 20000000 == 0)
//		{
//			BlinkLed();
//
//		}

		i++;
		RandomNumber = i;
    }

#if LWIP_IPV6==0
#if LWIP_DHCP==1
    while (1) {
	vTaskDelay(DHCP_FINE_TIMER_MSECS / portTICK_RATE_MS);
		if (server_netif.ip_addr.addr) {
			xil_printf("DHCP request success\r\n");
			print_ip_settings(&(server_netif.ip_addr), &(server_netif.netmask), &(server_netif.gw));
			print_echo_app_header();
			xil_printf("\r\n");
			sys_thread_new("echod", echo_application_thread, 0,
					THREAD_STACKSIZE,
					DEFAULT_THREAD_PRIO);
			break;
		}
		mscnt += DHCP_FINE_TIMER_MSECS;
		if (mscnt >= DHCP_COARSE_TIMER_SECS * 2000) {
			xil_printf("ERROR: DHCP request timed out\r\n");
			xil_printf("Configuring default IP of 192.168.1.10\r\n");
			IP4_ADDR(&(server_netif.ip_addr),  192, 168, 1, 10);
			IP4_ADDR(&(server_netif.netmask), 255, 255, 255,  0);
			IP4_ADDR(&(server_netif.gw),  192, 168, 1, 1);
			print_ip_settings(&(server_netif.ip_addr), &(server_netif.netmask), &(server_netif.gw));
			/* print all application headers */
			xil_printf("\r\n");
			xil_printf("%20s %6s %s\r\n", "Server", "Port", "Connect With..");
			xil_printf("%20s %6s %s\r\n", "--------------------", "------", "--------------------");

			print_echo_app_header();
			xil_printf("\r\n");
			sys_thread_new("echod", echo_application_thread, 0,
					THREAD_STACKSIZE,
					DEFAULT_THREAD_PRIO);
			break;
		}
	}
#endif
#endif
    vTaskDelete(NULL);
    return 0;
}

void vApplicationMallocFailedHook( void )
{
	xil_printf( "Gil Ramon vApplicationMallocFailedHook() called\n" );
}

void dummy(void)
{
	return;
}


void Print_IP(void)
{
	xil_printf("\n\r");
	print_ip_settings(&ipaddr, &netmask, &gw);
}

void UpdateGW(void)
{
	if (NumberOfArguments != 1)//error case
	{
		xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName, NumberOfArguments);
		return;
	}

	int ipaddress[4];
	char * pch;
	pch = strtok (tokens[1],".");
	for(int i =0 ; i < 4; i++)
	{
			u32 Num = (u32)strtol(pch, NULL, 10);
			if (Num <= 255 && Num >= 0)
			{
				ipaddress[i] = Num;
			}
			else
			{
				xil_printf("\n\r [%d] field is not valid ipv4 \n\r",Num);
				return;
			}
			pch = strtok (NULL,".");
	 }

	xil_printf("\n\r Gateway set to %d.%d.%d.%d \n\r", ipaddress[0] , ipaddress[1], ipaddress[2], ipaddress[3]);

		IP4_ADDR(&gw, ipaddress[0] , ipaddress[1], ipaddress[2], ipaddress[3]);
		netif_set_gw(netif, &gw);

}


void UpdateIPV4(void)
{
	if (NumberOfArguments != 1)//error case
	{
		xil_printf("\r\n Not argument size for command [%s] Number of args [%d],Please see help\r\n ",CurrentCommand->CommandName, NumberOfArguments);
		return;
	}

	int ipaddress[4];
	char * pch;
	pch = strtok (tokens[1],".");
	for(int i =0 ; i < 4; i++)
	{
			u32 Num = (u32)strtol(pch, NULL, 10);
			if (Num <= 255 && Num >= 0)
			{
				ipaddress[i] = Num;
			}
			else
			{
				xil_printf("\n\r [%d] field is not valid ipv4 \n\r",Num);
				return;
			}
			pch = strtok (NULL,".");
	 }

	xil_printf("\n\r IP address set to %d.%d.%d.%d \n\r", ipaddress[0] , ipaddress[1], ipaddress[2], ipaddress[3]);

		IP4_ADDR(&ipaddr, ipaddress[0] , ipaddress[1], ipaddress[2], ipaddress[3]);
		netif_set_ipaddr(netif, &ipaddr);

}
