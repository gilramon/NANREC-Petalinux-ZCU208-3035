//#include <stdio.h>
//#include <unistd.h>
//#include <stdlib.h>
//#include <sys/mman.h>
//#include <fcntl.h>
//
//
//
//
//#include <stdio.h>
//#include <error.h>
//
//#define PATH_MAX 1024
//
//int main(void)
//{
//  FILE *fp;
//  int status;
//  char path[PATH_MAX],buff[50];
//  int i =0;
//
//
//	while(1)
//	{
//
//		sprintf(buff,"devmem 0xa01a000c 32 %d",i);
//		  fp = popen(buff, "r");
//		  if (fp == NULL)
//		  {
//			perror("popen");
//			return -1;
//		  }
//		  i++;
//
//
//			  while (fgets(path, PATH_MAX, fp) != NULL)
//			  {
//				printf("%s", path);
//				/* do something you want with the return data */
//			  }
//
//
//			  status = pclose(fp);
//			  if (status == -1)
//			  {
//				perror("pclose");
//			  }
//
//			  usleep(500000);
//	}
//  return 0;
//}

/* A simple server in the internet domain using TCP
   The port number is passed as an argument */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


#define PATH_MAX 1024


void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
     int sockfd, newsockfd, portno;
     socklen_t clilen;
     char buffer[256];
     struct sockaddr_in serv_addr, cli_addr;
     int n;
     int i =0;
     FILE *fp;
     int status;
     char path[PATH_MAX],buff[50];





     if (argc < 2) {
         fprintf(stderr,"ERROR, no port provided\n");
         exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0)
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = atoi(argv[1]);
 //    portno = 7000;
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd,
                 (struct sockaddr *) &cli_addr,
                 &clilen);
     while(1)
     {

		sprintf(buff,"devmem 0xa01a000c 32 %d",i);
		fp = popen(buff, "r");
		if (fp == NULL)
		{
			perror("popen");
			return -1;
		}
		i++;


		while (fgets(path, PATH_MAX, fp) != NULL)
		{
			printf("%s", path);
			/* do something you want with the return data */
		}


		status = pclose(fp);
		if (status == -1)
		{
			perror("pclose");
		}





		 if (newsockfd < 0)
			  error("ERROR on accept");
		 bzero(buffer,256);
		 n = read(newsockfd,buffer,255);
		 if (n < 0) error("ERROR reading from socket");
		 printf("Here is the message: %s\n",buffer);
		 n = write(newsockfd,buffer,strlen(buffer));
		 if (n < 0) error("ERROR writing to socket");

		// usleep(500000);
     }
     close(newsockfd);
     close(sockfd);
     return 0;
}
