#ifndef __METAL_FREERTOS_DEVICE__H__
#define __METAL_FREERTOS_DEVICE__H__

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* __METAL_FREERTOS_DEVICE__H__ */
