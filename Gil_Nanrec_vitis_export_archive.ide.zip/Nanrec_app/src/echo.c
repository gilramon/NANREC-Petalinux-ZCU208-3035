/*
 * Copyright (C) 2016 - 2019 Xilinx, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <stdio.h>
#include <string.h>

#include "lwip/sockets.h"
#include "netif/xadapter.h"
#include "lwipopts.h"
#include "xil_printf.h"
#include "FreeRTOS.h"
#include "task.h"
#include "xuartps_hw.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include "xil_printf.h"

#include "xparameters.h"

#include "netif/xadapter.h"

//#include "platform.h"
#include "platform_config.h"
#if defined (__arm__) || defined(__aarch64__)
#include "xil_printf.h"
#endif

#include "lwip/tcp.h"
#include "xil_cache.h"
#include "sleep.h"


#define BUILDTM_YEAR (\
    __DATE__[7] == '?' ? 1900 \
    : (((__DATE__[7] - '0') * 1000 ) \
    + (__DATE__[8] - '0') * 100 \
    + (__DATE__[9] - '0') * 10 \
    + __DATE__[10] - '0'))

#define BUILDTM_MONTH (\
    __DATE__ [2] == '?' ? 1 \
    : __DATE__ [2] == 'n' ? (__DATE__ [1] == 'a' ? 1 : 6) \
    : __DATE__ [2] == 'b' ? 2 \
    : __DATE__ [2] == 'r' ? (__DATE__ [0] == 'M' ? 3 : 4) \
    : __DATE__ [2] == 'y' ? 5 \
    : __DATE__ [2] == 'l' ? 7 \
    : __DATE__ [2] == 'g' ? 8 \
    : __DATE__ [2] == 'p' ? 9 \
    : __DATE__ [2] == 't' ? 10 \
    : __DATE__ [2] == 'v' ? 11 \
    : 12)

#define BUILDTM_DAY (\
    __DATE__[4] == '?' ? 1 \
    : ((__DATE__[4] == ' ' ? 0 : \
    ((__DATE__[4] - '0') * 10)) + __DATE__[5] - '0'))


void Ethernet_WriteReg32(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_ReadReg32(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_WriteReg64(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_ReadReg64(u16 i_OpCode, char * i_data,u32 i_length);
void ParseKratosFrame(char * i_buffer,int i_length);
void SendMessageBackToClient(u16 i_Op_Code,char * i_data,u32 i_DataLength);
void Ethernet_GetChannel(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_GetChannel_direct_sending(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_SetPlayback(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_ResetPaybackAddressCounter(u8 i_OpCode, char * i_data,u32 i_length);
//void Ethernet_WritePlayback(char * i_data,u32 i_length);
void Ethernet_ReturnToNormalMode(u16 i_OpCode, char * i_data,u32 i_length);
void Ethernet_EnterPlaybackmode(u16 i_OpCode, char * i_data,u32 i_length);
void PrintBuffer(char * i_data,u32 i_length);
void Ethernet_GetVersion(u16 i_OpCode, char * i_data,u32 i_length);
void ReadChannelAndSendToHost_Direct(UINTPTR i_Addr);



#define THREAD_STACKSIZE 1024
/*
 * Max number of telnet connections that this application can serve.
 * The existing implementation does not support closing of an existing telnet.
 * Once a telnet connection is made, it stays for ever.
 */
#define MAX_CONNECTIONS 1
int new_sd[MAX_CONNECTIONS];
int connection_index = 0;

u32 AddressToWrite = 0xa1000000;
char ExitCheckFrameMode = 0;

//Gil: Buffer size
//#define MINIMUM_SIZE 0x4000
#define DATA_TO_SEND_SIZE (0x20001)
u32 DataToSend[DATA_TO_SEND_SIZE];

u16_t echo_port = 7;

void print_echo_app_header()
{
//    xil_printf("%20s %6d %s\r\n", "echo server",
//                        echo_port,
//                        "$ telnet <board_ip> 7");

	    xil_printf("Eyal GMI Port: [%d]\r\n", echo_port);

}
int GlobalTCP_pcb = 0;
int FramesCounter = 0;
int PlaybackMode = 0;
extern int DebugFlag;

#define RECV_BUF_SIZE 30000
//char recv_buf[RECV_BUF_SIZE];
char BufferToSendOverTCPIP[1000];
char ReceivedData[1000];
int i=0;
/* thread spawned for each connection */
void process_echo_request(void *p)
{
	int sd = *(int *)p;
	//int RECV_BUF_SIZE = 2048;
	//char recv_buf[RECV_BUF_SIZE];
	int n;
	xil_printf("Ethernet Connection accepted \n\r" );

	GlobalTCP_pcb = sd;

	while (1) {
		memset(DataToSend, 0, DATA_TO_SEND_SIZE * 4);
		/* read a max of RECV_BUF_SIZE bytes from socket */
		if ((n = read(sd, DataToSend, DATA_TO_SEND_SIZE)) < 0) {
			xil_printf("%s: error reading from socket %d, closing socket\r\n", __FUNCTION__, sd);
			break;
		}

//		/* break if the recved message = "quit" */
//		if (!strncmp(recv_buf, "quit", 4))
//			break;

		/* break if client closed connection */
		if (n <= 0)
		{


			break;
		}

		/* handle request */
		xil_printf("\r\nPacket received length [%d] ",n);
//		PrintBuffer(recv_buf,400);
			ParseKratosFrame((char *)DataToSend,n); //Gil: maximux [1446] bytes
//		if ((nwrote = write(sd, recv_buf, n)) < 0) {
//			xil_printf("%s: ERROR responding to client echo request. received = %d, written = %d\r\n",
//					__FUNCTION__, n, nwrote);
//			xil_printf("Closing socket %d\r\n", sd);
//			break;
//		}
	}
	xil_printf("Ethernet Connection closed \n\r" );
	/* close connection */
	close(sd);
	vTaskDelete(NULL);
}

void echo_application_thread()
{
	int sock;
	int size;
#if LWIP_IPV6==0
	struct sockaddr_in address, remote;

	memset(&address, 0, sizeof(address));

	if ((sock = lwip_socket(AF_INET, SOCK_STREAM, 0)) < 0)
		return;

	address.sin_family = AF_INET;
	address.sin_port = htons(echo_port);
	address.sin_addr.s_addr = INADDR_ANY;
#else
	struct sockaddr_in6 address, remote;

	memset(&address, 0, sizeof(address));

	address.sin6_len = sizeof(address);
	address.sin6_family = AF_INET6;
	address.sin6_port = htons(echo_port);

	memset(&(address.sin6_addr), 0, sizeof(address.sin6_addr));
כי
	if ((sock = lwip_socket(AF_INET6, SOCK_STREAM, 0)) < 0)
		return;
#endif

	if (lwip_bind(sock, (struct sockaddr *)&address, sizeof (address)) < 0)
		return;

	lwip_listen(sock, 0);

	size = sizeof(remote);

	while (1) {
		if ((new_sd[connection_index] = lwip_accept(sock, (struct sockaddr *)&remote, (socklen_t *)&size)) > 0) {
			sys_thread_new("echos", process_echo_request,
				(void*)&(new_sd[connection_index]),
				1024,
				3);
//			if (++connection_index>= MAX_CONNECTIONS) {
//				break;
//			}
		}
	}
	xil_printf("Maximum number of connections reached, No further connections will be accepted\r\n");
//    sys_thread_new("echod", echo_application_thread, 0,
//		1024,
//		3);
	vTaskSuspend(NULL);
}

int TotalBytesReceivedDirectMode = 0;
int GlobalPlaybackBytesCounter = 0;
void GetPlayback_direct(char * i_buffer,int i_length)
{


	TotalBytesReceivedDirectMode += i_length;
	printf("0x83 buffer received, length [%d] Total [%d]\n\r",i_length,TotalBytesReceivedDirectMode);

	//u32 DataTowrite = 0 ;
//	while(i < i_length)
//	{
//		DataTowrite = 0 ; // Gil: Each sample is 32 bit
//		DataTowrite = i_buffer[i];
//		DataTowrite <<= 8;
//		DataTowrite |= i_buffer[i+1];
//		DataTowrite <<= 8;
//		DataTowrite |= i_buffer[i+2];
//		DataTowrite <<= 8;
//		DataTowrite |= i_buffer[i+3];
//
//		Xil_Out32(AddressToWrite,DataTowrite);
//
//		AddressToWrite+=4;
//		i+=4;
//	}

	for(int i=0; i < i_length ; i++)
	{

		u32 DataTowrite = Xil_In32(AddressToWrite);

		int temp = GlobalPlaybackBytesCounter % 4;
		switch(temp)
		{
			case 0:
				DataTowrite = i_buffer[i];
				Xil_Out32(AddressToWrite,DataTowrite);
				break;

			case 1:
				DataTowrite <<= 8;
				DataTowrite |= i_buffer[i];
				Xil_Out32(AddressToWrite,DataTowrite);
				break;

			case 2:
				DataTowrite <<= 8;
				DataTowrite |= i_buffer[i];
				Xil_Out32(AddressToWrite,DataTowrite);
				break;

			case 3:
				DataTowrite <<= 8;
				DataTowrite |= i_buffer[i];
				Xil_Out32(AddressToWrite,DataTowrite);

				AddressToWrite+=4;
				break;
		}

		GlobalPlaybackBytesCounter++;



	}
}

void SendASSCIMessage(char * i_message)
{
	xil_printf(i_message);

//	SendMessageBackToClient(0x2000,i_message,strlen(i_message)); //Gil: 0x20 is Opcode to send ASCII
}


void ParseKratosFrame(char * i_buffer,int i_length)
{


	if(PlaybackMode == 1)
	{
		if(i_buffer[0] == 0x83 && i_buffer[1] == 0x83 && i_buffer[2] == 0x83 && i_buffer[3] == 0x83)
		{
			PlaybackMode = 0;
		//sprintf((char *)DataToSend,"Packet received - Not T project [0x%x] [0x%x] [0x%x] [0x%x]",i_buffer[0],i_buffer[1],i_buffer[2],i_buffer[3]);
			SendASSCIMessage("Return to Normal Mode \r\n");
		}
		else
		{
			GetPlayback_direct(i_buffer,i_length);
		}
		return;
	}

	if(i_buffer[0] != 0x54)
	{

		sprintf((char *)DataToSend,"Packet received - Not T project [0x%x] [0x%x] [0x%x] [0x%x]",i_buffer[0],i_buffer[1],i_buffer[2],i_buffer[3]);
		SendASSCIMessage((char *)DataToSend);

		return;
	}

	ushort CalculatedCheckSum = 0;
	for(int i=0; i < i_length - 2;i++) // Check sum - 2 bytes. Is the result of the sum of all bytes in the frame except the CRC Field.
	{
		CalculatedCheckSum += i_buffer[i];
	}

	ushort ReceivedCheckSum = 0;
	ReceivedCheckSum = i_buffer[i_length-1];
	ReceivedCheckSum <<= 8;
	ReceivedCheckSum |= i_buffer[i_length-2];

	if(ReceivedCheckSum != CalculatedCheckSum)
	{
		//char DataToSend[100];
		sprintf((char *)DataToSend,"Packet received - Bad Check Sum Recieved [0x%x] Calculated [%x]",ReceivedCheckSum,CalculatedCheckSum);
		SendASSCIMessage((char *)DataToSend);
		return;
	}

	u16 Op_Code = 0;
	Op_Code = i_buffer[1] << 8 | i_buffer[2];

	u32 Data_length = 0;
	Data_length = i_buffer[6];
	Data_length <<= 8;
	Data_length |= i_buffer[5];
	Data_length <<= 8;
	Data_length |= i_buffer[4];
	Data_length <<= 8;
	Data_length |= i_buffer[3];


	for(int i=0 ; i < Data_length;i++)
	{
		ReceivedData[i] = i_buffer[i+7];
	}


	printf("Opcode received [0x%x], length [%d] total length [%d]\n\r",Op_Code,(int)Data_length,i_length);

	if(DebugFlag == 1)
	{
		xil_printf("Buffer data: ");
		for(int i=0; i < i_length;i++)
		{
			xil_printf("0x%x ",i_buffer[i]);
		}
	}




	switch(Op_Code)
	{
		case 0x0:
			break;

		case 0x0100: // Gil: read 32 bit register
			Ethernet_GetVersion(Op_Code,ReceivedData,Data_length);
			break;


		case 0x7000: // Gil: read 32 bit register
			Ethernet_ReadReg32(Op_Code,ReceivedData,Data_length);
			break;

		case 0x7100: // Gil: write 32 bit register
			Ethernet_WriteReg32(Op_Code,ReceivedData,Data_length);
			break;

		case 0x7200: // Gil: read 64 bit register
			Ethernet_ReadReg64(Op_Code,ReceivedData,Data_length);
			break;

		case 0x7300: // Gil: write 64 bit register
			Ethernet_WriteReg64(Op_Code,ReceivedData,Data_length);
			break;

		case 0x8000: // Gil: Get channel data
			Ethernet_GetChannel(Op_Code,ReceivedData,Data_length);
			break;

		case 0x8100: // Gil: Get channel data
			Ethernet_GetChannel_direct_sending(Op_Code,ReceivedData,Data_length);
			break;

		case 0x8200: // Gil: Get channel data
			Ethernet_SetPlayback(Op_Code,ReceivedData,Data_length);
			break;

		case 0x8300:
			Ethernet_ResetPaybackAddressCounter(Op_Code,ReceivedData,Data_length);
			break;

		case 0x8400:
			Ethernet_EnterPlaybackmode(Op_Code,ReceivedData,Data_length);
			break;

//		case 0x85:
//			Ethernet_ReturnToNormalMode(Op_Code,ReceivedData,Data_length);
//			break;


		default:
			printf("UnHandaled Opcode received [0x%x], length [%d]\n\r",Op_Code,(int)Data_length);
			break;

	}



}


void SendMessageBackToClient(u16 i_Op_Code,char * i_data,u32 i_DataLength)
{



	BufferToSendOverTCPIP[0] =0x54;

	BufferToSendOverTCPIP[1] = i_Op_Code >> 8;

	BufferToSendOverTCPIP[2] = i_Op_Code;

	BufferToSendOverTCPIP[6] = i_DataLength >> 24;

	BufferToSendOverTCPIP[5] =i_DataLength >> 16;

	BufferToSendOverTCPIP[4] =i_DataLength >> 8;

	BufferToSendOverTCPIP[3] =i_DataLength;



	for(int i=0; i < i_DataLength;i++)
	{
		BufferToSendOverTCPIP[i+7] = i_data[i];
	}

	ushort CheckSum = 0;
	for(int i=0; i < i_DataLength + 7 ;i++)
	{
		CheckSum += BufferToSendOverTCPIP[i];
	}

	//CheckSum = ((CheckSum << 8) & 0xff00) | ((CheckSum >> 8) & 0x00ff);

	int CheckSumPosition = i_DataLength + 7;
	BufferToSendOverTCPIP[CheckSumPosition] = CheckSum;
	BufferToSendOverTCPIP[CheckSumPosition + 1] = CheckSum >> 8;


	int TotalPackaetLength = i_DataLength + 9; // Gil:  1 Preamble, 1 Opcode, 4 length, 2 Checksum and Data length so total Data length + 8






	//tcp_write(GlobalTCP_pcb, BufferToSendOverTCPIP, TotalPackaetLength, 1);

			int nwrote = 0;
			if ((nwrote = write(GlobalTCP_pcb, BufferToSendOverTCPIP, TotalPackaetLength)) < 0)
			{
				xil_printf("%s: ERROR  received = %d, written = %d\r\n",
						__FUNCTION__, TotalPackaetLength, nwrote);
				xil_printf("Closing socket %d\r\n", GlobalTCP_pcb);

			}

			xil_printf("\r\nSending back [0x%x], TotalPackaetLength [%d] sent [%d]\n\r",i_Op_Code,TotalPackaetLength,nwrote);

			//vTaskDelay(10);

}

void SendAddressMustBeAligned(void)
{
	char DataToSend[100];
	sprintf(DataToSend,"Address must be aligned to 0x4");
	SendASSCIMessage(DataToSend);
}



void Ethernet_GetVersion(u16 i_OpCode, char * i_data,u32 i_length)
{

//
	UINTPTR Addr = 0xa01a0000;
	u32 MajorMinorVersion = Xil_In32(Addr);

	//printf("MajorMinorVersion = %d",MajorMinorVersion);
    Addr = 0xa01a0004;
	u32 DataVersion = Xil_In32(Addr);

	//sprintf((char *)DataToSend,"\r\nFPGA Major/Minor [%d] \r\n FPGA Date Version [%d] \r\nSW version [%s %s]",MajorMinorVersion,DataVersion,__DATE__,__TIME__);

	DataToSend[0] = MajorMinorVersion;
	DataToSend[1] = DataVersion;
	DataToSend[2] = BUILDTM_YEAR;
	DataToSend[3] = BUILDTM_MONTH;
	DataToSend[4] = BUILDTM_DAY;
//	//printf("%s",(char *)DataToSend);

	SendMessageBackToClient(i_OpCode,(char *)DataToSend,20);
}

void Ethernet_ReadReg32(u16 i_OpCode, char * i_data,u32 i_length)
{

//
	UINTPTR Addr = 0;

	Addr = i_data[3];
	Addr <<= 8;
	Addr |= i_data[2];
	Addr <<= 8;
	Addr |= i_data[1];
	Addr <<= 8;
	Addr |= i_data[0];

	if(Addr % 4 != 0)
	{
		SendAddressMustBeAligned();
		return;
	}

	u32 Value = Xil_In32(Addr);




	////////////////////////////// Send Data Back ////////////////////////////

	char DataToSend[4];

	DataToSend[0] = Value;
	Value >>=8;
	DataToSend[1] = Value;
	Value >>=8;
	DataToSend[2] = Value;
	Value >>=8;
	DataToSend[3] = Value;
//	Value >>=8;
//	DataToSend[4] = Value;
//	Value >>=8;
//	DataToSend[5] = Value;
//	Value >>=8;
//	DataToSend[6] = Value;
//	Value >>=8;
//	DataToSend[7] = Value;
//	Value >>=8;


	SendMessageBackToClient(i_OpCode,DataToSend,4);
}



void Ethernet_WriteReg32(u16 i_OpCode, char * i_data,u32 i_length)
{

//
	UINTPTR Addr = 0;



	Addr = i_data[3];
	Addr <<= 8;
	Addr |= i_data[2];
	Addr <<= 8;
	Addr |= i_data[1];
	Addr <<= 8;
	Addr |= i_data[0];

	if(Addr % 4 != 0)
	{
		SendAddressMustBeAligned();
		return;
	}

	u32 Value  = i_data[7];
	Value <<= 8;
	Value |= i_data[6];
	Value <<= 8;
	Value |= i_data[5];
	Value <<= 8;
	Value |= i_data[4];

	Xil_Out32(Addr,Value);

	////////////////////////////// Send Data Back ////////////////////////////

	char DataToSend[1];

	SendMessageBackToClient(i_OpCode,DataToSend,0);


}



void Ethernet_ReadReg64(u16 i_OpCode, char * i_data,u32 i_length)
{

//
	UINTPTR Addr = 0;



	Addr = i_data[0];
	Addr <<= 8;
	Addr |= i_data[1];
	Addr <<= 8;
	Addr |= i_data[2];
	Addr <<= 8;
	Addr |= i_data[3];
	Addr <<= 8;
	Addr |= i_data[4];
	Addr <<= 8;
	Addr |= i_data[5];
	Addr <<= 8;
	Addr |= i_data[6];
	Addr <<= 8;
	Addr |= i_data[7];

	if(Addr % 4 != 0)
	{
		SendAddressMustBeAligned();
		return;
	}

	u64 Value = Xil_In64(Addr);




	////////////////////////////// Send Data Back ////////////////////////////

	char DataToSend[8];

	DataToSend[7] = Value;
	Value >>=8;
	DataToSend[6] = Value;
	Value >>=8;
	DataToSend[5] = Value;
	Value >>=8;
	DataToSend[4] = Value;
	Value >>=8;
	DataToSend[3] = Value;
	Value >>=8;
	DataToSend[2] = Value;
	Value >>=8;
	DataToSend[1] = Value;
	Value >>=8;
	DataToSend[0] = Value;
	Value >>=8;


	SendMessageBackToClient(i_OpCode,DataToSend,8);
}



void Ethernet_WriteReg64(u16 i_OpCode, char * i_data,u32 i_length)
{

//
	UINTPTR Addr = 0;



	Addr = i_data[0];
	Addr <<= 8;
	Addr |= i_data[1];
	Addr <<= 8;
	Addr |= i_data[2];
	Addr <<= 8;
	Addr |= i_data[3];
	Addr <<= 8;
	Addr |= i_data[4];
	Addr <<= 8;
	Addr |= i_data[5];
	Addr <<= 8;
	Addr |= i_data[6];
	Addr <<= 8;
	Addr |= i_data[7];

	if(Addr % 4 != 0)
	{
		SendAddressMustBeAligned();
		return;
	}

	u64 Value  = i_data[8];
	Value <<= 8;
	Value |= i_data[9];
	Value <<= 8;
	Value |= i_data[10];
	Value <<= 8;
	Value |= i_data[11];
	Value <<= 8;
	Value |= i_data[12];
	Value <<= 8;
	Value |= i_data[13];
	Value <<= 8;
	Value |= i_data[14];
	Value <<= 8;
	Value |= i_data[15];

	Xil_Out64(Addr,Value);

	////////////////////////////// Send Data Back ////////////////////////////

	char DataToSend[1];

	SendMessageBackToClient(i_OpCode,DataToSend,0);


}

u32 SwapInt32toBigLitteEndian(u32 i_Int)
{
	// Swap endian (big to little) or (little to big)
	uint32_t b0,b1,b2,b3;


	b0 = (i_Int & 0x000000ff) << 24u;
	b1 = (i_Int & 0x0000ff00) << 8u;
	b2 = (i_Int & 0x00ff0000) >> 8u;
	b3 = (i_Int & 0xff000000) >> 24u;

	int res = b0 | b1 | b2 | b3;

	return res;
}

void ReadChannelAndSendToHost_Direct(UINTPTR i_Addr)
{

	//int TotalPacketsToSend = (0x20000 * 4) / DATA_TO_SEND_SIZE;
	//int PacketSizeinBytes = DATA_TO_SEND_SIZE - 0x10;
	int i=0;

	DataToSend[0] = 0x81818181;
	for(i = 1; i < DATA_TO_SEND_SIZE;i++)
	{
		DataToSend[i]=  SwapInt32toBigLitteEndian(Xil_In32(i_Addr));
		i_Addr+=4;
	}

		int nwrote = 0;
		int TotalPackaetLength = DATA_TO_SEND_SIZE * 4;

		vTaskDelay(50);

		xil_printf("Send = [%d] Total bytes\r\n", TotalPackaetLength);


		if ((nwrote = write(GlobalTCP_pcb, DataToSend, TotalPackaetLength)) < 0)
		{
			xil_printf("%s: ERROR  received = %d, written = %d\r\n",__FUNCTION__, TotalPackaetLength, nwrote);
			xil_printf("Closing socket %d\r\n", GlobalTCP_pcb);

		}

}

void ReadChannelAndSendToHost(UINTPTR i_Addr,int i_SizeToReadBytes,int i_PacketSizeinBytes,int i_TimeBetweenFrames)
{

	int TotalPacketsToSend = i_SizeToReadBytes / i_PacketSizeinBytes;

	char OpCode= 0x80;
//	if(i_Addr == 0xa1000000)
//	{
//		OpCode = 0x80;
//	}
//	else
//	{
//		OpCode = 0x81;
//	}




	int i=0;
	int TotalConterSamples32bit = 0; // Gil: the size is 0x80000 bytes so 0x20000 Int32
	for(int j=0; j < TotalPacketsToSend;j++)
	{
		i=0;
		while( i < (i_PacketSizeinBytes / 4) && TotalConterSamples32bit < 0x20000)
		{

			DataToSend[i]=  SwapInt32toBigLitteEndian(Xil_In32(i_Addr));
			//printf("Addr = [0x%lx] DataToSend = [0x%x]\r\n",Addr,DataToSendRecord[i] );

			i_Addr+=4;
			i++;
			TotalConterSamples32bit++;
		}

			printf("Addr = [0x%lx] send Packet = [%d] \r\n",i_Addr,j );

			SendMessageBackToClient(OpCode,(char *)DataToSend,(i_PacketSizeinBytes));

//			TickType_t CurrentTick = xTaskGetTickCount();
//
//			while(xTaskGetTickCount() - CurrentTick < (i_TimeBetweenFrames));
//
////			while( xTaskGetTickCount() – CurrentTick <  pdMSTO_TICKS(i_TimeBetweenFrames))
////			{
////
////			}


			vTaskDelay(i_TimeBetweenFrames);




	}
}


void Ethernet_GetChannel_direct_sending(u16 i_OpCode, char * i_data,u32 i_length)
{
	//	Record Ch0:    Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit
	//	 Record Ch1     Start Address = 0x00_A108_0000;  Length = 512Kbyte = 128K*32bit
	//	 Playback Ch0: Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit

			UINTPTR Addr = 0xa1000000;

			char ChannelNumber = i_data[0];

			switch(ChannelNumber)
			{
				case 0:
					Addr = 0xa1000000;
					break;

				case 1:
					Addr = 0xa1080000;
					break;

				default:
					Addr = 0xa1000000;
					break;
			}

//			u32 SizeOfTotalData = 0 ;
//			SizeOfTotalData = i_data[1];
//			SizeOfTotalData <<= 8;
//			SizeOfTotalData |= i_data[2];
//			SizeOfTotalData <<= 8;
//			SizeOfTotalData |= i_data[3];
//			SizeOfTotalData <<= 8;
//			SizeOfTotalData |= i_data[4];



			sprintf((char *)DataToSend,"\r\n OpCode [0x%x] [Read Channel [%d] Total Size [%d] \r\n",i_OpCode,ChannelNumber,DATA_TO_SEND_SIZE);
			SendASSCIMessage((char *)DataToSend);

			printf("\r\n %s",(char *)DataToSend);

			SendMessageBackToClient(i_OpCode,(char *)DataToSend,0);

			ReadChannelAndSendToHost_Direct(Addr);
}

void Ethernet_GetChannel(u16 i_OpCode, char * i_data,u32 i_length)
{

//	Record Ch0:    Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit
//	 Record Ch1     Start Address = 0x00_A108_0000;  Length = 512Kbyte = 128K*32bit
//	 Playback Ch0: Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit

		UINTPTR Addr = 0xa1000000;

		char ChannelNumber = i_data[0];

		switch(ChannelNumber)
		{
		case 0:
			Addr = 0xa1000000;
			break;

		case 1:
			Addr = 0xa1080000;
			break;

		default:
			Addr = 0xa1000000;
			break;
		}


		u32 SizeOfTotalData = 0 ;
		SizeOfTotalData = i_data[1];
		SizeOfTotalData <<= 8;
		SizeOfTotalData |= i_data[2];
		SizeOfTotalData <<= 8;
		SizeOfTotalData |= i_data[3];
		SizeOfTotalData <<= 8;
		SizeOfTotalData |= i_data[4];


		u32 SizeOfEachFrame = 0 ;
		SizeOfEachFrame = i_data[5];
		SizeOfEachFrame <<= 8;
		SizeOfEachFrame |= i_data[6];
		SizeOfEachFrame <<= 8;
		SizeOfEachFrame |= i_data[7];
		SizeOfEachFrame <<= 8;
		SizeOfEachFrame |= i_data[8];

		u32 TimeBetweenFrames = 0 ;
		TimeBetweenFrames = i_data[9];
		TimeBetweenFrames <<= 8;
		TimeBetweenFrames |= i_data[10];
		TimeBetweenFrames <<= 8;
		TimeBetweenFrames |= i_data[11];
		TimeBetweenFrames <<= 8;
		TimeBetweenFrames |= i_data[12];


		sprintf((char *)DataToSend,"\r\nRead Channel [%d] Total Size [%d] Frame Size [%d] TimeBetweenFrames [%d] \r\n",ChannelNumber,(int)SizeOfTotalData,(int)SizeOfEachFrame,(int)TimeBetweenFrames);
		SendASSCIMessage((char *)DataToSend);

		printf("\r\n %s",(char *)DataToSend);

		ReadChannelAndSendToHost(Addr,SizeOfTotalData,SizeOfEachFrame,TimeBetweenFrames);






}

//void Ethernet_GetChannel1(u8 i_OpCode, char * i_data,u32 i_length)
//{
//
////	Record Ch0:    Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit
////	 Record Ch1     Start Address = 0x00_A108_0000;  Length = 512Kbyte = 128K*32bit
////	 Playback Ch0: Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit
//
//		UINTPTR Addr = 0xa1080000;
//
//		char ChannelNumber = i_data[0];
//
//		u32 Size = 0 ;
//		Size = i_data[1];
//		Size <<= 8;
//		Size |= i_data[2];
//		Size <<= 8;
//		Size |= i_data[3];
//		Size <<= 8;
//		Size |= i_data[4];
//
//		ReadChannelAndSendToHost(Addr,Size);
//}

void Ethernet_EnterPlaybackmode(u16 i_OpCode, char * i_data,u32 i_length)
{
	PlaybackMode = 1;
	AddressToWrite = 0xa1000000;
	TotalBytesReceivedDirectMode = 0;
	GlobalPlaybackBytesCounter = 0;

	SendASSCIMessage("Enter to Playback mode \r\n");


	SendMessageBackToClient(i_OpCode,(char *)DataToSend,0);
}

void Ethernet_ReturnToNormalMode(u16 i_OpCode, char * i_data,u32 i_length)
{
	AddressToWrite = 0xa1000000;
	ExitCheckFrameMode = 0;



	SendMessageBackToClient(i_OpCode,(char *)DataToSend,0);
}

void Ethernet_ResetPaybackAddressCounter(u8 i_OpCode, char * i_data,u32 i_length)
{
	AddressToWrite = 0xa1000000;
	FramesCounter = 0;



	SendMessageBackToClient(i_OpCode,(char *)DataToSend,0);
}



void PrintBuffer(char * i_data,u32 i_length)
{
	i=0;
	while(i < i_length)
	{

		if(i < 370 && i > 352)
		{

			xil_printf("%x ", i_data[i]);
		}


		i++;
	}
	xil_printf("]");

}


//void Ethernet_WritePlayback(char * i_data,u32 i_length)
//{
//	int i=0;
//	xil_printf("Packet received in Non Kratos Protocol mode length [%d] Number [%d]\r\n",i_length,FramesCounter);
//	FramesCounter++;
//	//PrintBuffer(i_data,12);
//	if(i_length % 4 != 0)
//	{
//		xil_printf("Warning I length not devide by 4\r\n");
//	}
//
//		while(i < (i_length / 4))
//		{
//			u32 DataTowrite = 0 ; // Gil: Each sample is 32 bit
//			DataTowrite = i_data[i];
//			DataTowrite <<= 8;
//			DataTowrite |= i_data[i+1];
//			DataTowrite <<= 8;
//			DataTowrite |= i_data[i+2];
//			DataTowrite <<= 8;
//			DataTowrite |= i_data[i+3];
//
//			if( DataTowrite == 0x11223344)
//			{
//					ExitCheckFrameMode = 0;
//					return;
//			}
////
////
////			xil_printf("i = [%d] Address [%x], DataTowrite [%x]\r\n",i,AddressToWrite,DataTowrite);
////			vTaskDelay(10);
//
//			Xil_Out32(AddressToWrite,DataTowrite);
//
//			AddressToWrite+=4;
//			i+=4;
//
//
//		}
//}

void Ethernet_SetPlayback(u16 i_OpCode, char * i_data,u32 i_length)
{

//	Record Ch0:    Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit
//	 Record Ch1     Start Address = 0x00_A108_0000;  Length = 512Kbyte = 128K*32bit
//	 Playback Ch0: Start Address = 0x00_A100_0000;  Length = 512Kbyte = 128K*32bit


	//xil_printf("Packet received for Playback [%d] Number [%d]\r\n",i_length,FramesCounter);
	FramesCounter++;

		//int * temp = (int *)i_data;
		int i=0;
		while(i < i_length)
		{
			u32 DataTowrite = 0 ; // Gil: Each sample is 32 bit
			DataTowrite = i_data[i];
			DataTowrite <<= 8;
			DataTowrite |= i_data[i+1];
			DataTowrite <<= 8;
			DataTowrite |= i_data[i+2];
			DataTowrite <<= 8;
			DataTowrite |= i_data[i+3];

			Xil_Out32(AddressToWrite,DataTowrite);

//						xil_printf("i = [%d] Address [%x], DataTowrite [%x]\r\n",i,AddressToWrite,DataTowrite);
//						vTaskDelay(10);

			AddressToWrite+=4;
			i+=4;
		}

		SendMessageBackToClient(i_OpCode,(char *)DataToSend,0);
//		if(AddressToWrite > 0xA1000160)
//		{
//			sprintf((char *)DataToSend,"Address [0x%x]",(int)AddressToWrite);
//			SendASSCIMessage((char *)DataToSend);
//		//SendMessageBackToClient(i_OpCode,(char *)DataToSend,0);
//		}

}



